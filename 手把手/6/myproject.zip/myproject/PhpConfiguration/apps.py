from django.apps import AppConfig


class PhpconfigurationConfig(AppConfig):
    name = 'PhpConfiguration'
