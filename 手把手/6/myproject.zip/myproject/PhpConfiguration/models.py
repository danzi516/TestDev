from django.db import models
from project.models import projectModel
# Create your models here.
class PhpConfigurationModel(models.Model):
    id = models.AutoField(primary_key=True)
    project_id = models.IntegerField
    parameter = models.CharField(max_length=255)
    dev_path = models.CharField(max_length=255)
    project = models.ForeignKey(projectModel, related_name='PhpConfiguration_project', on_delete=models.CASCADE)
    class Meta:
        db_table = "php_configuration"


