import json
import os
import subprocess

from django.views.generic import View
# Create your views here.
from django.http import HttpResponse

from myproject.settings import BASE_DIR
from ProjectEnvironment.models import ProjectEnvironmentModel
# from myproject.BaseDao import BaseDAO
from myproject.utils import ModelsUtil, Encrypted_text
from PhpConfiguration.models import PhpConfigurationModel
from project.models import projectModel
from django.db.models import Q

#数据库操作
#添加数据
class InsertRecord(View):
    def post(self,request):
        dto = json.loads(request.body)
        project_id = dto.get("project_id","")
        parameter = dto.get("parameter", "")
        dev_path = dto.get("dev_path", "")
        Record = PhpConfigurationModel(project_id=project_id, parameter=parameter,dev_path=dev_path)
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

#删除数据
class DeleteById(View):
    def post(self,request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = PhpConfigurationModel(id=id)
        Record.delete()
        return  HttpResponse(json.dumps({"code":20000}),content_type="application/json")

#修改数据
class UpdateBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = PhpConfigurationModel.objects.get(id=id)
        if dto.get('project_id'):
            Record.project_id = dto.get('project_id')
        if dto.get('parameter'):
            Record.parameter = dto.get('parameter')
        if dto.get('dev_path'):
            Record.dev_path = Encrypted_text(dto.get('dev_path'))
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

#查询所有
class SelectAll(View):
    def post(self,request):
        listRes = PhpConfigurationModel.objects.values()
        listRes = list(listRes)
        return  HttpResponse(json.dumps({"modelList": listRes, "code": 20000}),content_type="application/json")

#根据条件查询
class SelectBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        recordList = PhpConfigurationModel.objects.values()
        if dto.get('id'):
            recordList = recordList.filter(id=dto.get('id'))
        if dto.get('project_id'):
            recordList = recordList.filter(project_id=dto.get('project_id'))
        if dto.get('parameter'):
            recordList = recordList.filter(parameter=dto.get('parameter'))
        if dto.get('dev_path'):
            recordList = recordList.filter(dev_path=dto.get('dev_path'))
        listRes = list(recordList)
        return HttpResponse(json.dumps({"modelList": listRes, "code": 20000}),content_type="application/json")

#分页查询
class SelectByPage(View):
    def post(self,request):
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1) * limit
        sort = dto.get('sort')
        order = dto.get('order')
        length = len(PhpConfigurationModel.objects.all())
        targets = PhpConfigurationModel.objects.all()
        if not limit:
            targets = PhpConfigurationModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        for row in targets:
            data_set.append(ModelsUtil(PhpConfigurationModel).toDict(row))
        return HttpResponse(json.dumps({"rows":data_set,"total":length,"code":20000}), content_type='application/json')

#（临时使用）测试服务器发布php应用，environment_id写死测试服务器
class TestPhpProjectPublish(View):
    def post(self, request):
        dto = json.loads(request.body)
        id = dto.get('id')
        environment_id = dto.get('environment_id')
        Record1 = PhpConfigurationModel.objects.get(id=id)
        project_id = Record1.project_id
        parameter = Record1.parameter
        dev_path = Record1.dev_path
        Record2 = projectModel.objects.get(id=project_id)
        project_name = Record2.name
        project_workspace = Record2.workspace
        project_type = Record2.type
        Record3 = ProjectEnvironmentModel.objects.get(Q(project_id=project_id) & Q(environment_id=environment_id))
        dir_publish = Record3.dir_publish
        podname = Record3.podname.strip()
        if podname is not None and podname != '':
            command = str(BASE_DIR) + "/shell/php_publish.sh %s %s %s %s %s %s %s" % (project_name, parameter, dir_publish, project_workspace, dev_path, project_type, podname)
            ret = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True, encoding="utf-8")
            msg = str(ret.stdout.read()).splitlines()
            packapge_name = msg[-1]
            update_content = msg[-5]
            line = msg[0:-5]
            for i in range(len(line)):
                line[i] = line[i] + "\n"
            publish_list = ''.join(line)
            ret.stdout.close()
            return HttpResponse(json.dumps({"msg": packapge_name, "list": publish_list, "update_content": update_content, "code": 20000}), content_type="application/json")
        else:
            command = str(BASE_DIR) + "/shell/php_publish.sh %s %s %s %s %s %s" % (project_name, parameter, dir_publish, project_workspace, dev_path, project_type)
            # os.system(command % (project_name, parameter, dir_publish, project_workspace, dev_path, project_type))
            ret = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True, encoding="utf-8")
            msg = str(ret.stdout.read()).splitlines()
            packapge_name = msg[-1]
            update_content = msg[-4]
            line = msg[0:-4]
            for i in range(len(line)):
                line[i] = line[i] + "\n"
            publish_list = ''.join(line)
            ret.stdout.close()
            return HttpResponse(json.dumps({"msg": packapge_name, "list": publish_list, "update_content": update_content, "code": 20000}), content_type="application/json")

        # if podname == None or podname == '':
        #     command = str(BASE_DIR) + "/shell/php_publish.sh %s %s %s %s %s %s"
        #     # os.system(command % (project_name, parameter, dir_publish, project_workspace, dev_path, project_type))
        #     ret = os.popen(command % (project_name, parameter, dir_publish, project_workspace, dev_path, project_type))
        #     msg = ret.readlines()
        #     for i in range(len(msg)):
        #         msg[i] = msg[i].strip()
        #     packapge_name = msg[-1]
        #     update_content_path = msg[-3] + "/" + msg[-4]
        #     update_content = msg[-4]
        #     ret.close()
        #     file = open(update_content_path,'r')
        #     list = file.read()
        #     file.close()
        #     return HttpResponse(json.dumps({"msg": packapge_name, "list": list, "update_content": update_content, "code": 20000}), content_type="application/json")
        # else:
        #     command = str(BASE_DIR) + "/shell/php_publish.sh %s %s %s %s %s %s %s"
        #     # os.system(command % (project_name, parameter, dir_publish, project_workspace, dev_path, project_type, podname))
        #     ret = os.popen(command % (project_name, parameter, dir_publish, project_workspace, dev_path, project_type, podname))
        #     msg = ret.readlines()
        #     for i in range(len(msg)):
        #         msg[i] = msg[i].strip()
        #     packapge_name = msg[-1]
        #     update_content_path = msg[-3] + "/" + msg[-4]
        #     update_content = msg[-4]
        #     ret.close()
        #     file = open(update_content_path, 'r')
        #     list = file.read()
        #     file.close()
        #     return HttpResponse(json.dumps({"msg": packapge_name, "list": list, "update_content": update_content, "code": 20000}), content_type="application/json")


# class TestPhpProjectPublish1(View):
#     def post(self, request):
#         dto = json.loads(request.body)
#         id = dto.get('id')
#         environment_id = dto.get('environment_id')
#         Record1 = PhpConfigurationModel.objects.get(id=id)
#         project_id = Record1.project_id
#         parameter = Record1.parameter
#         dev_path = Record1.dev_path
#         Record2 = projectModel.objects.get(id=project_id)
#         project_name = Record2.name
#         project_workspace = Record2.workspace
#         project_type = Record2.type
#         Record3 = ProjectEnvironmentModel.objects.get(Q(project_id=project_id) & Q(environment_id=environment_id))
#         dir_publish = Record3.dir_publish
#         podname = Record3.podname
#         if podname == None or podname == '':
#             command = str(BASE_DIR) + "/shell/php_publish.sh %s %s %s %s %s %s" % (project_name, parameter, dir_publish, project_workspace, dev_path, project_type)
#             # os.system(command % (project_name, parameter, dir_publish, project_workspace, dev_path, project_type))
#             ret = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True, encoding="utf-8")
#             msg = str(ret.stdout.read()).splitlines()
#             packapge_name = msg[-1]
#             update_content = msg[-4]
#             line = msg[0:-4]
#             for i in range(len(line)):
#                 line[i] = line[i] + "\n"
#             publish_list = ' '.join(line)
#             ret.stdout.close()
#             return HttpResponse(json.dumps({"msg": packapge_name, "list": publish_list, "update_content": update_content, "code": 20000}), content_type="application/json")
#         else:
#             command = str(BASE_DIR) + "/shell/php_publish.sh %s %s %s %s %s %s %s" % (project_name, parameter, dir_publish, project_workspace, dev_path, project_type, podname)
#             ret = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True, encoding="utf-8")
#             msg = str(ret.stdout.read()).splitlines()
#             packapge_name = msg[-1]
#             update_content = msg[-5]
#             line = msg[0:-5]
#             for i in range(len(line)):
#                 line[i] = line[i] + "\n"
#             publish_list = ' '.join(line)
#             ret.stdout.close()
#             return HttpResponse(json.dumps({"msg": packapge_name, "list": publish_list, "update_content": update_content, "code": 20000}), content_type="application/json")
