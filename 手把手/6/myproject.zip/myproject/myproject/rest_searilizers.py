﻿from rest_framework import serializers

from ProjectBulid.models import ProjectBulidModel
from ProversionRecord.models import ProversionRecordModel
from UserProduct.models import UserProductModel
from UserRole.models import UserRoleModel
from product.model import productModel
from proversion.models import proversionModel
from user.model import userModel
from project.models import projectModel
from ProductProject.models import ProductProjectModel
from environment.models import EnvironmentModel
from ProjectEnvironment.models import ProjectEnvironmentModel
from credentials.models import CredentialsModel
from PhpConfiguration.models import PhpConfigurationModel
from role.models import RoleModel

class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = RoleModel
        fields = '__all__'

class UserSimplerSerializer(serializers.ModelSerializer):
    class Meta:
        model = userModel
        fields = '__all__'

class RoleByUserSerializer(serializers.ModelSerializer):
    user = UserSimplerSerializer(read_only=True)
    role = RoleSerializer(read_only=True)
    class Meta:
        model = UserRoleModel
        fields = '__all__'

class UserSerializer(serializers.ModelSerializer):
    UserRole_user = RoleByUserSerializer(many=True,read_only=True)
    class Meta:
        model = userModel
        fields = '__all__'

class ProductSerializer(serializers.ModelSerializer):
    creator = UserSerializer( read_only=True)
    close = UserSerializer( read_only=True)
    class Meta:
        model = productModel
        fields = '__all__'

class PhpConfigurationSerializer(serializers.ModelSerializer):
    class Meta:
        model = PhpConfigurationModel
        fields = '__all__'

class ProjectSerializer(serializers.ModelSerializer):
    PhpConfiguration_project = PhpConfigurationSerializer(many=True, read_only=True)
    creator = UserSerializer( read_only=True)
    close = UserSerializer( read_only=True)
    class Meta:
        model = projectModel
        fields = '__all__'


class CredentialsSerializer(serializers.ModelSerializer):
    class Meta:
        model = CredentialsModel
        fields = ('id','type','username','password','name')

class EnvironmentSerializer(serializers.ModelSerializer):
    credentials = CredentialsSerializer(read_only=True)
    class Meta:
        model = EnvironmentModel
        fields = '__all__'

class proversionSerializer(serializers.ModelSerializer):
    product = ProductSerializer(read_only=True)
    class Meta:
        model = proversionModel
        fields = '__all__'

class ProversionRecordSerializer(serializers.ModelSerializer):
    proversion = proversionSerializer(read_only=True)
    class Meta:
        model = ProversionRecordModel
        fields = '__all__'

class UserRoleSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    role = RoleSerializer(read_only=True)
    class Meta:
        model = UserRoleModel
        Fields = '__all__'


class UserProductSerializer(serializers.ModelSerializer):
    product = ProductSerializer(read_only=True)
    user = UserSerializer(read_only=True)
    class Meta:
        model = UserProductModel
        fields = '__all__'

class ProductProjectSerializer(serializers.ModelSerializer):
    project = ProjectSerializer(read_only=True)
    product = ProductSerializer(read_only=True)
    class Meta:
        model = ProductProjectModel
        fields = ('id','product_id','project_id','project','product')


class ProjectEnvironmentSerializer(serializers.ModelSerializer):
    project = ProjectSerializer(read_only=True)
    environment = EnvironmentSerializer(read_only=True)
    class Meta:
        model = ProjectEnvironmentModel
        fields = ('id','project_id','environment_id','dir_publish','log_type','log_name','log_path','podname','file_conf','project','environment')

class ProjectBulidSerializer(serializers.ModelSerializer):
    project = ProjectSerializer(read_only=True)
    class Meta:
        model = ProjectBulidModel
        fields = '__all__'