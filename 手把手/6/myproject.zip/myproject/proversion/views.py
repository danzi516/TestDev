import json

from django.views.generic import View
# Create your views here.
from django.http import HttpResponse
from django.db.models import Q
#数据库操作
#添加数据
# from myproject.BaseDao import BaseDAO
from myproject import rest_searilizers
from myproject.utils import DateEncoder, ModelsUtil, Encrypted_text
from proversion.models import proversionModel

def duplicateVerify(str1, str2):
    Record = proversionModel.objects.filter(Q(product_id=str1) & Q(version=str2)).first()
    # Record = userModel.objects.get(username=str)
    if Record is not None:
        return False
    else:
        return True

class InsertRecord(View):
    def post(self,request):
        dto = json.loads(request.body)
        product_id = dto.get("product_id","")
        version = dto.get("version", "")
        Record = proversionModel(product_id=product_id,version=version)
        if(duplicateVerify(product_id,version)):
            Record.save()
            return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
        else:
            return HttpResponse(json.dumps({"message": '记录已存在', "code": 10002}), content_type="application/json")
        # Record.save()
        # return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
#删除数据
class DeleteById(View):
    def post(self,request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = proversionModel(id=id)
        Record.delete()
        return  HttpResponse(json.dumps({"code":20000}),content_type="application/json")

#修改数据
class UpdateBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = proversionModel.objects.get(id=id)
        product_id = Record.product_id
        version = Record.version
        if dto.get('product_id'):
            Record.product_id = dto.get('product_id')
        if dto.get('version'):
            Record.version = dto.get('version')
            if (Record.version != version):
                if (duplicateVerify(product_id, Record.version)==False):
                    return HttpResponse(json.dumps({"code": 10002, "message": "记录重复"}), content_type="application/json")
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

#查询所有
class SelectAll(View):
    def post(self,request):
        listRes = proversionModel.objects.values()
        listRes = list(listRes)
        return  HttpResponse(json.dumps({"modelList": listRes, "code": 20000},cls=DateEncoder),content_type="application/json")

#根据条件查询
class SelectBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        recordList = proversionModel.objects.values()
        if dto.get('id'):
            recordList = recordList.filter(id=dto.get('id'))
        if dto.get('product_id'):
            recordList = recordList.filter(product_id=dto.get('product_id'))
        if dto.get('version'):
            recordList = recordList.filter(version=dto.get('version'))
        listRes = list(recordList)
        return HttpResponse(json.dumps({"modelList": listRes, "code": 20000}, cls=DateEncoder),content_type="application/json")

#分页查询
class SelectByPage(View):
    def post(self,request):
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1) * limit
        sort = dto.get('sort')
        order = dto.get('order')
        if dto.get('product_id'):
            data_set = proversionModel.objects.all().filter(product_id=dto.get('product_id'))
        length = len(data_set)
        targets = data_set
        if not limit:
            targets = proversionModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        listRes = rest_searilizers.proversionSerializer(targets, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"rows":data_set,"total":length,"code":20000}), content_type='application/json')

