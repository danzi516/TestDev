from django.apps import AppConfig


class ProversionConfig(AppConfig):
    name = 'proversion'
