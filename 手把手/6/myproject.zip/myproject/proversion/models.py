from django.db import models
from product.model import productModel

# Create your models here.

class proversionModel(models.Model):
    id = models.AutoField(primary_key=True)
    product_id = models.IntegerField
    version = models.CharField(max_length=255)
    product = models.ForeignKey(productModel, related_name='product', on_delete=models.CASCADE)
    class Meta:
        db_table = "proversion"
