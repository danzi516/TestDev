from django.apps import AppConfig


class UserroleConfig(AppConfig):
    name = 'UserRole'
