from django.db.models import Q
from django.views.generic import View
from django.http import HttpResponse
from UserRole.models import UserRoleModel
from myproject import rest_searilizers
import json
from myproject.utils import DateEncoder

# 数据库操作
def duplicateVerify(str1, str2):
    Record = UserRoleModel.objects.filter(Q(user_id=str1) & Q(role_id=str2)).first()
    if Record is not None:
        return False
    else:
        return True

#添加
class InsertRecord(View):
    def post(self,request):
        dto = json.loads(request.body)
        user_id = dto.get("user_id","")
        role_id = dto.get("role_id","")
        Record = UserRoleModel(user_id=user_id,role_id=role_id)
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
        # if(duplicateVerify(user_id,role_id)):
        #     Record.save()
        #     return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
        # else:
        #     return HttpResponse(json.dumps({"message": '记录已存在', "code": 10002}), content_type="application/json")

#删除
class DeleteById(View):
    def post(self, request):
        dto = json.loads(request.body)
        jsonReq = dto
        Record = UserRoleModel.objects.get(id=jsonReq.get('id'))
        Record.delete()
        return HttpResponse(json.dumps({"code":20000}),content_type="application/json")

#根据id修改
class UpdateBySelective(View):
    def post(self, request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = UserRoleModel.objects.get(id=id)
        # user_id = Record.user_id
        # role_id = Record.role_id
        if dto.get('user_id'):
            Record.user_id = dto.get('user_id')
        if dto.get('role_id'):
            Record.role_id = dto.get('role_id')
        # if dto.get('user_id'):
        #     Record.user_id = dto.get('user_id')
        #     if(Record.user_id != user_id):
        #         if (duplicateVerify(Record.user_id,role_id)==False):
        #             return HttpResponse(json.dumps({"code": 10002, "message": "记录重复"}), content_type="application/json")
        # if dto.get('role_id'):
        #     Record.role_id = dto.get('role_id')
        #     if(Record.role_id != role_id):
        #         if (duplicateVerify(user_id,Record.role_id)==False):
        #             return HttpResponse(json.dumps({"code": 10002, "message": "记录重复"}), content_type="application/json")
        Record.save()
        return HttpResponse(json.dumps({"code":20000}),content_type="application/json")

#查询所有
class SelectAll(View):
    def post(self,request):
        listRes = UserRoleModel.objects.all()
        listRes = rest_searilizers.UserRoleSerializer(listRes, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"modelList": data_set, "code": 20000}, cls=DateEncoder),
                            content_type="application/json")

#根据条件查询
class SelectBySelective(View):
    def post(self,request):
        recordList = UserRoleModel.objects.all()
        dto = json.loads(request.body)
        if dto.get('id'):
            recordList = recordList.filter(id=dto.get('id'))
        if dto.get('user_id'):
            recordList = recordList.filter(user_id=dto.get('user_id'))
        if dto.get('role_id'):
            recordList = recordList.filter(role_id=dto.get('role_id'))
        listRes = rest_searilizers.UserRoleSerializer(recordList, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return  HttpResponse(json.dumps({"modelList":data_set,"code":20000},cls=DateEncoder),content_type="application/json")

#分页查询
class SelectByPage(View):
    def post(self,request):
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1)*limit
        sort = dto.get('sort')
        order = dto.get('order')
        length = len(UserRoleModel.objects.all())
        targets= UserRoleModel.objects.all()
        if not limit:
            targets = UserRoleModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        listRes = rest_searilizers.UserRoleSerializer(targets, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse({"rows":data_set,"total":length,"code":20000}, content_type='application/json')