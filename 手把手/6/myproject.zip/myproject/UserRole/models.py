from django.db import models
from user.model import userModel
from role.models import RoleModel


class UserRoleModel(models.Model):
    id = models.IntegerField(primary_key=True, db_column='id')
    user_id = models.IntegerField
    role_id = models.IntegerField
    user = models.ForeignKey(userModel, related_name='UserRole_user', on_delete=models.CASCADE)  # 关联外键
    role = models.ForeignKey(RoleModel, related_name='UserRole_role', on_delete=models.CASCADE)  # 关联外键
    class Meta:
        db_table = "user_role"

# Create your models here.
