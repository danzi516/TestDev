from django.db import models

# Create your models here.
from proversion.models import proversionModel


class ProversionRecordModel(models.Model):
    id = models.AutoField(primary_key=True)
    proversion_id = models.IntegerField
    datenumber = models.CharField(max_length=20)
    project_name = models.CharField(max_length=255)
    package_name = models.CharField(max_length=255)
    package_type = models.IntegerField(max_length=11)
    ftp_path = models.CharField(max_length=255)
    folder_name_num = models.CharField(max_length=255)
    proversion = models.ForeignKey(proversionModel, related_name='proversion', on_delete=models.CASCADE)
    class Meta:
        db_table = "proversion_record"

