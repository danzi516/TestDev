import json
import os
from io import BytesIO

from django.views.generic import View
# Create your views here.
from django.http import HttpResponse,FileResponse
from django.db.models import Q

from myproject.settings import BASE_DIR
from myproject.utils import DateEncoder, ModelsUtil
from ProversionRecord.models import ProversionRecordModel
from product.model import productModel
from proversion.models import proversionModel
from django.db.models import Max
import datetime
import openpyxl

class InsertRecord(View):
    def post(self,request):
        dto = json.loads(request.body)
        proversion_id = dto.get("proversion_id", "")
        project_name = dto.get("project_name", "")
        package_name = dto.get("package_name", "")
        package_type = dto.get("package_type", "")
        ftp_path = dto.get("ftp_path", "")
        datenumber = dto.get("datenumber", "")
        folder_name_num = dto.get("folder_name_num", "")
        Record = ProversionRecordModel(proversion_id=proversion_id, datenumber=datenumber, project_name=project_name, package_name=package_name, package_type=package_type, ftp_path=ftp_path, folder_name_num=folder_name_num)
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

#删除数据
class DeleteById(View):
    def post(self,request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = ProversionRecordModel(id=id)
        Record.delete()
        return  HttpResponse(json.dumps({"code":20000}),content_type="application/json")

#修改数据
class UpdateBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = ProversionRecordModel.objects.get(id=id)
        if dto.get('proversion_id'):
            Record.proversion_id = dto.get('proversion_id')
        if dto.get('project_name'):
            Record.project_name = dto.get('project_name')
        if dto.get('package_name'):
            Record.package_name = dto.get('package_name')
        if dto.get('package_type'):
            Record.package_type = dto.get('package_type')
        if dto.get('ftp_path'):
            Record.ftp_path = dto.get('ftp_path')
        if dto.get('datenumber'):
            Record.datenumber = dto.get('datenumber')
        if dto.get('folder_name_num'):
            Record.folder_name_num = dto.get('folder_name_num')
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

#查询所有
class SelectAll(View):
    def post(self,request):
        listRes = ProversionRecordModel.objects.values()
        listRes = list(listRes)
        return  HttpResponse(json.dumps({"modelList": listRes, "code": 20000},cls=DateEncoder),content_type="application/json")

#根据条件查询
class SelectBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        recordList = ProversionRecordModel.objects.values()
        if dto.get('id'):
            recordList = recordList.filter(id=dto.get('id'))
        if dto.get('proversion_id'):
            recordList = recordList.filter(proversion_id=dto.get('proversion_id'))
        if dto.get('project_name'):
            recordList = recordList.filter(project_name=dto.get('project_name'))
        if dto.get('package_name'):
            recordList = recordList.filter(package_name=dto.get('package_name'))
        if dto.get('package_type'):
            recordList = recordList.filter(package_type=dto.get('package_type'))
        if dto.get('ftp_path'):
            recordList = recordList.filter(ftp_path=dto.get('ftp_path'))
        if dto.get('datenumber'):
            recordList = recordList.filter(datenumber=dto.get('datenumber'))
        if dto.get('folder_name_num'):
            recordList = recordList.filter(folder_name_num=dto.get('folder_name_num'))
        listRes = list(recordList)
        return HttpResponse(json.dumps({"modelList": listRes, "code": 20000}, cls=DateEncoder),content_type="application/json")

#分页查询
class SelectByPage(View):
    def post(self,request):
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1) * limit
        sort = dto.get('sort')
        order = dto.get('order')
        length = len(ProversionRecordModel.objects.all())
        targets = ProversionRecordModel.objects.all()
        if not limit:
            targets = ProversionRecordModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        for row in targets:
            data_set.append(ModelsUtil(ProversionRecordModel).toDict(row))
        return HttpResponse(json.dumps({"rows":data_set,"total":length,"code":20000}), content_type='application/json')

#上传发布内容到ftp服务器
class FtpUpload(View):
    def post(self,request):
        dto = json.loads(request.body)
        product_id = dto.get('product_id')
        if product_id is None or product_id == '':
            return HttpResponse(json.dumps({"code": 10002, "message": "产品ID为空"}), content_type="application/json")
        version = dto.get('version')
        if version is None or version == '':
            return HttpResponse(json.dumps({"code": 10002, "message": "产品版本号为空"}), content_type="application/json")
        projectlist = []
        projectlist = dto.get('projectlist')
        if projectlist == []:
            return HttpResponse(json.dumps({"code": 10002, "message": "至少勾选一个组件"}), content_type="application/json")
        Record1 = productModel.objects.get(id=product_id)
        Record2 = proversionModel.objects.get(Q(product_id=product_id) & Q(version=version))
        proversion_id = Record2.id
        ftp_path = Record1.ftp_path
        command1 = str(BASE_DIR) + "/shell/ftp_mkdir.sh %s %s"
        ret1 = os.popen(command1 % (ftp_path, version))
        folder_name_num = ret1.read()
        folder_name_num = folder_name_num.strip()
        ret1.close()
        ftp_folder_path = ftp_path + "/" + version + "/publish/" + folder_name_num
        datenumber=version + "_" + folder_name_num
        for item in projectlist:
            projectname=item['name']
            if projectname is None or projectname == '':
                return HttpResponse(json.dumps({"code": 10002, "message": "组件名称为空"}), content_type="application/json")
            projecttype=item['type']
            if projecttype is None or projecttype == '':
                return HttpResponse(json.dumps({"code": 10002, "message": "组件类型为空"}), content_type="application/json")
            projectparameter = item['parameter']
            if projectparameter is None or projectparameter == '':
                return HttpResponse(json.dumps({"code": 10002, "message": "组件参数为空"}), content_type="application/json")
            if projecttype == 1 and projectparameter == 'full':
                package_type = 1
            elif projecttype == 1 and projectparameter == 'incremental':
                package_type = 2
            elif projecttype == 3:
                package_type = 2
            elif projecttype == 4:
                package_type = 2
            projectworkspace = item['workspace']
            if projectworkspace is None or projectworkspace == '':
                return HttpResponse(json.dumps({"code": 10002, "message": "组件工作空间为空"}), content_type="application/json")
            command2 = str(BASE_DIR) + "/shell/ftp_upload.sh %s %s %s %s"
            ret2 = os.popen(command2 % (ftp_folder_path,projectworkspace,projecttype,projectparameter))
            msg = ret2.readlines()
            for i in range(len(msg)):
                msg[i] = msg[i].strip()
            ftp_path = msg[-2]
            package_name = msg[-1]
            ret2.close()
            Record = ProversionRecordModel(proversion_id=proversion_id, datenumber=datenumber,project_name=projectname, package_name=package_name,package_type=package_type, ftp_path=ftp_path, folder_name_num=folder_name_num)
            Record.save()
        return HttpResponse(json.dumps({"message": "上传ftp成功",  "code": 20000}), content_type="application/json")

#根据产品版本号，查找上传ftp的记录
class FindDatenumberByProversion(View):
    def post(self,request):
        dto = json.loads(request.body)
        proversion_id = dto.get('proversion_id')
        Record = ProversionRecordModel.objects.all().filter(proversion_id=proversion_id).values('datenumber').annotate(max=Max('id')).order_by('-max')[:10]
        Record = list(Record)
        return HttpResponse(json.dumps({"modelList": Record, "code": 20000}, cls=DateEncoder),
                            content_type="application/json")

#将ftp的上传内容导出excel文档
class ExportXlsx(View):
    def post(self,request):
        dto = json.loads(request.body)
        list = dto.get('list')
        userName = dto.get('userName')
        publishEnv = dto.get('publishEnv')
        date = datetime.datetime.now().strftime('%Y/%m/%d')
        file = str(BASE_DIR)+'/templet/xxx发布清单.xlsx'
        workbook = openpyxl.load_workbook(file)
        worksheet = workbook.active
        worksheet['B2'] = str(date)
        worksheet['F2'] = str(userName)
        worksheet['K2'] = str(publishEnv)
        i=4
        for index in range(len(list)):
            worksheet['A'+str(i+index)] = index+1
            if list[index]['project_name']:
                worksheet['B' + str(i + index)] = list[index]['project_name'].encode()
            if 'pubType' in list[0]:
                worksheet['C' + str(i + index)] = list[index]['pubType'].encode()
            if 'isNet' in list[0]:
                worksheet['D' + str(i + index)] = list[index]['isNet'].encode()
            if 'realmName' in list[0]:
                worksheet['E' + str(i + index)] = list[index]['realmName'].encode()
            if list[index]['ftp_path']:
                worksheet['F' + str(i + index)] = list[index]['ftp_path'].encode()
            if list[index]['package_name']:
                worksheet['G' + str(i + index)] = list[index]['package_name'].encode()
            if 'environmentData' in list[0]:
                worksheet['H' + str(i + index)] = list[index]['environmentData'].encode()
            if list[index]['package_type'] == 1:
                worksheet['I' + str(i + index)] = "全量".encode()
            if list[index]['package_type'] == 2:
                worksheet['I' + str(i + index)] = "增量".encode()

        sio = BytesIO()
        workbook.save(sio)
        sio.seek(0)

        # response = HttpResponse(sio.getvalue(), content_type='application/vnd.ms-excel') .xls格式
        response = HttpResponse(sio.getvalue(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') #.xlsx格式
        # 文件名称中文设置
        from django.utils.encoding import escape_uri_path
        response["requestType"] = "file"
        response["Access-Control-Expose-Headers"] = "requestType"
        # response['Content-Disposition'] = 'attachment; filename={}'.format(escape_uri_path('test.xlsx'))
        # response.write(sio.getvalue())  # 必须要给response写入一下数据，不然不生效
        return response







