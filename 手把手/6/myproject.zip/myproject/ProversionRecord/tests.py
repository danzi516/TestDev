
import xlrd
import openpyxl
from xlutils.copy import copy

from myproject.settings import BASE_DIR

file = 'C:\\Users\wangl\Desktop\税账通发布清单.xlsx'
# read_book = xlrd.open_workbook(file, formatting_info=True)
# read_book = openpyxl.load_workbook(filename = file)
# write_book = copy(read_book)
# sheet = write_book.get_sheet(0)
# sheet.write(7, 1, 3)
# sheet.write(7, 2, 'jp-pjj-core-1.war')
# write_book.save('C:\\Users\wangl\Desktop\\test.xls')

# msg = [1,2,3,4,5]
# for i in reversed(msg):
#     print(i)

# workbook=openpyxl.load_workbook(file)
# # worksheet=workbook.sheetnames[0]
# worksheet = workbook.active
# print(worksheet)
# # worksheet.cell('A7').value = 3
# # worksheet.cell('B7').value = 'jp-pjj-core-1.war'
# # worksheet.cell(7, 2, 'jp-pjj-core-1.war')
# worksheet['A7'] =3
# worksheet['B7'] ='jp-pjj-core-1.war'
# worksheet['B2'] ='2021-2-7'
# worksheet['K2'] ='生产'
# workbook.save(filename='C:\\Users\wangl\Desktop\\test.xls')


file = str(BASE_DIR)+'/templet/xxx发布清单.xlsx'
print(file)