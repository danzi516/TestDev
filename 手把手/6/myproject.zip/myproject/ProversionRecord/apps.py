from django.apps import AppConfig


class ProversionrecordConfig(AppConfig):
    name = 'ProversionRecord'
