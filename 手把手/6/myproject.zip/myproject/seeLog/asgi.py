from django.urls import re_path,path

from seeLog import consumers
from seeLog import fortress

websocket_urlpatterns = [
    # 前端请求websocket连接
    path('seeLog/<projectId>/<environment_id>/<userId>', consumers.EchoConsumer),
    path('fortress/<podName>/<userId>', fortress.EchoConsumer),
]