import inspect
import os

import paramiko
from asgiref.sync import async_to_sync
from channels.generic.websocket import WebsocketConsumer
import threading
from channels.layers import get_channel_layer
import time
import subprocess
import ctypes
from django.db.models import Q
from myproject.settings import LOGINFO #LOGINFO是一个典全局字变量，存储用户在线情况
from ProjectEnvironment.models import ProjectEnvironmentModel
# import pyinotify
channel_layer = get_channel_layer()

#
# class MyEventHandler(pyinotify.ProcessEvent):
#     def __init__(self, filename,channel_name): #初始化类，2个必传参数:filename,channel_name
#         self.channel_name = channel_name  #定义通道名称为类作用域
#         self._fh = open(filename, 'r') #定义文件对象为类作用域
#         self._fh.seek(0, 2) #光标定位在文件末尾
#         super(MyEventHandler, self).__init__() #调用父类的初始化,父类pyinotify.ProcessEvent
#     def process_IN_MODIFY(self, event): #定义process_IN_MODIFY函数,当发生修改时的处理方法
#             line = self._fh.read() #读取文件内容，这里读的是修改时新增的内容
#             if line:
#                 channel_layer = get_channel_layer()
#                 async_to_sync(channel_layer.send)(  #通过channels的通道发送消息给服务端
#                     self.channel_name,
#                     {
#                         "type": "send.message",
#                         "text": str(line)
#                     }
#                 )
class EchoConsumer(WebsocketConsumer): #继承channels的WebsocketConsumer类
    def connect(self):  #当服务端与客户端连接时调用此方法
        self.accept()
        project_id = self.scope["url_route"]["kwargs"]['projectId']
        environment_id = self.scope["url_route"]["kwargs"]['environment_id']
        self.userId = self.scope["url_route"]["kwargs"]['userId']
        projectEnvironment = ProjectEnvironmentModel.objects.all().filter(Q(project_id=project_id) & Q(environment_id=environment_id))[0]
        self.podName = projectEnvironment.podname
        log_path = projectEnvironment.log_path
        pod_log_path = projectEnvironment.pod_log_path
        if projectEnvironment.log_type == 2:
            log_name = "catalina-" + time.strftime("%Y-%m-%d", time.localtime()) + ".out"
        else:
            log_name = projectEnvironment.log_name
        if self.userId in LOGINFO:  #判断userId是否在线
            index = 99 #赋值，保证index的值大于在线用户数
            for i in range(len(LOGINFO[self.userId])): #循环用户当前正在查看的所有日志信息
                if LOGINFO[self.userId][i]['podName'] == self.podName: #判断是否已经在查看pod日志
                    index = i   #赋值给index
                    break    #退出
            if index != 99: #如果上面赋了值，此处肯定不为99
                async_to_sync(self.channel_layer.send)(  #发送给前端信息
                    LOGINFO[self.userId][index]['channel_name'],
                    {
                        "type": "send.message",
                        "text": '为节约资源，1个组件只有1个窗口查看，此窗口连接关闭',
                    },
                )
                # pid = LOGINFO[self.userId][index]['pid']
                # _close_Subprocess(pid)
                async_to_sync(self.channel_layer.send)( #发送给服务端消息，由服务端关闭已经查看的pod日志的客户端
                    LOGINFO[self.userId][index]['channel_name'],
                    {
                        "type": "send.message",
                        "text": 'close',
                    },
                )
            else:   #如果为99,表示第一次查看该pod的日志
                if len(LOGINFO[self.userId]) == 5:  #判断是否已经查看了5个pod日志，这里没有判断大于5的情况，因为是顺序的+1，不会出现大于5
                    async_to_sync(self.channel_layer.send)( #如果已经查看了5个pod日志，发送消息给服务端，由服务端通知第一个pod日志的客户端
                        LOGINFO[self.userId][0]['channel_name'],
                        {
                            "type": "send.message",
                            "text": '为节约资源，最多同时打开5个窗口查看日志，此窗口连接关闭',
                        },
                    )
                    async_to_sync(self.channel_layer.send)( #发送消息给服务端，由服务端关闭与第一个pod日志的客户端
                        LOGINFO[self.userId][0]['channel_name'],
                        {
                            "type": "send.message",
                            "text": 'close',
                        },
                    )
            t1 = threading.Thread(target=self.taillog,args=(self.podName,self.userId,log_path,log_name,pod_log_path)) #线程调用taillog方法
            t1.start()
            self.tid = t1.ident #获取线程id
            LOGINFO[self.userId].append({'podName': self.podName, 'tid':self.tid,'channel_name':self.channel_name}) #将用户信息写入全局变量
        else: #用户首次查看日志，直接线程调用taillog方法
            t1 = threading.Thread(target=self.taillog, args=(self.podName, self.userId,log_path,log_name,pod_log_path))
            t1.start()
            self.tid = t1.ident  #获取线程id
            LOGINFO[self.userId] = [{'podName': self.podName, 'tid':self.tid,'channel_name':self.channel_name}] #将用户信息写入全局变量

    def receive(self, text_data=None, bytes_data=None): #当服务端接收消息时调用此方法
        if text_data=='close':
            self.disconnect() #断开连接
        async_to_sync(self.channel_layer.send)(  #发送消息
            self.channel_name,
            {
                "type": "send.message",
                "text": text_data,
            },
        )

    def send_message(self, event): #服务端发送消息方法,此方法为自定义方法
        self.send(text_data=event["text"])  #send()，实际的消息发送

    def disconnect(self, close_code): #服务端断开连接方法
        index = 99
        pid = 0
        for i in range(len(LOGINFO[self.userId])):
            if LOGINFO[self.userId][i]['tid'] == self.tid:  #根据线程id，找到用户对应的在线信息位置
                index = i
                break
        if index != 99:
            # pid = LOGINFO[self.userId][index]['pid']
            LOGINFO[self.userId].pop(index) #删除指定位置的用户在线情况
        _async_raise(self.tid,SystemExit) #强制关闭线程
        # _close_Subprocess(pid)
        self.close()

    def taillog(self,podName,userId,log_path,log_name,pod_log_path):
        # command = "kubectl exec -ti `kubectl get pods -n kube-system |grep Running |grep ^" + podName + " |awk '{print $1}'` -n kube-system --  tail -" + userId + "f "+pod_log_path+"/"+log_name
        # ret = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
        #                        stderr=subprocess.PIPE,
        #                        encoding="utf-8")
        # out = _query_Subprocess(self.userId,self.podName)
        # pid = str(int(out.stdout.read().splitlines()[0]))
        # for item in LOGINFO[self.userId]:
        #     if item['tid'] == self.tid:
        #         item['pid'] = pid
        ##############################上面的方法永久注释，不要恢复，仅做为记录学习###################################


        # _initKubectl(podName)
        command = "kubectl exec -ti `kubectl get pods -n kube-system |grep Running |grep ^" + podName + " |awk '{print $1}'` -n kube-system --  tail -f "+pod_log_path+"/"+log_name
        # # os.system(command+" &") #os.system这个是阻塞式的subprocess是非阻塞的
        # subprocess.Popen(command, shell=True, stdout=subprocess.PIPE,stderr=subprocess.PIPE,encoding="utf-8")
        # filename = log_path + '/' + log_name
        # wm = pyinotify.WatchManager() #新建管理器
        # handler = MyEventHandler(filename, self.channel_name) #获取MyEventHandler类
        # notifier = pyinotify.Notifier(wm, handler) #交给Notifier进行处理
        # wm.add_watch(filename, pyinotify.IN_MODIFY) #添加要监控的文件，以及要监控的事件
        # notifier.loop() #循环处理事件
def _async_raise(tid, exctype):
    """raises the exception, performs cleanup if needed"""
    try:
        tid = ctypes.c_long(tid)
        if not inspect.isclass(exctype):
            exctype = type(exctype)
        res = ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, ctypes.py_object(exctype))
        if res == 0:
            # pass
            raise ValueError("invalid thread id")
        elif res != 1:
            # """if it returns a number greater than one, you're in trouble,
            # and you should call it again with exc=NULL to revert the effect"""
            ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, None)
            raise SystemError("PyThreadState_SetAsyncExc failed")
    except Exception as err:
        print(err)

def _close_Subprocess(pid): #杀掉进程
    # command = "ps -ef |grep kubectl |grep " + userId + " |grep " + podName + " |awk '{print $2}' |xargs kill -9"
    command = "kill -9 "+ pid
    out = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    out.wait()

def _query_Subprocess(userId,podName): #废弃，没有用到
    command = "ps -ef |grep kubectl |grep " + userId + " |grep " + podName + " |awk '{print $2}'"
    out = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    pid = out
    out.wait()
    return pid

def _initKubectl(podName): #查询pod的进程id
    command = "ps -ef |grep kubectl |grep " + podName + " |awk '{print $2}'"
    out = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    pids = out.stdout.readlines()
    for pid in pids:
        _close_Subprocess(str(int(pid)))


