import inspect
import select

import paramiko
from asgiref.sync import async_to_sync
from channels.generic.websocket import WebsocketConsumer
import threading
from channels.layers import get_channel_layer
import ctypes

from myproject.settings import BASE_DIR
from myproject.utils import  connectLog



channel_layer = get_channel_layer()


class EchoConsumer(WebsocketConsumer):
    def connect(self):
        self.accept()
        podName = self.scope["url_route"]["kwargs"]['podName']
        self.userId = self.scope["url_route"]["kwargs"]['userId']
        t1 = threading.Thread(target=self.taillog,args=(podName,))
        t1.start()
        self.tid = t1.ident

    def receive(self, text_data=None, bytes_data=None):
        if text_data=='close':
            self.disconnect()
        async_to_sync(self.channel_layer.send)(
            self.channel_name,
            {
                "type": "send.message",
                "text": text_data,
            },
        )

    def send_message(self, event):
        self.send(text_data=event["text"])

    def disconnect(self, close_code):
        self.channel.close()
        self.client.close()
        _async_raise(self.tid,SystemExit)
        self.close()

    def taillog(self,podName):
        channel,client =connectLog()
        self.client = client
        self.channel = channel

        while True:
            BUF_SIZE = 1
            transport = client.get_transport()
            transport.set_keepalive(1)
            # channel = transport.open_session()
            # channel.settimeout(3)
            # channel = transport.open_session()
            # channel.settimeout(3)
            # cmd = "tail -f /usr/local/tomcat8.5/logs/localhost.2020-12-17.log | grep -E 'error|statistics'"
            cmd = "fab log:"+podName
            channel.send(cmd + "\n")
            lines_to_process = b''
            while transport.is_active():
                rl, wl, xl = select.select([channel], [], [], 0.0)
                if len(rl) > 0:
                    buf = channel.recv(BUF_SIZE)
                    if len(buf) > 0:
                        lines_to_process += buf
                        if buf==b'\n' :
                            channel_layer = get_channel_layer()
                            async_to_sync(channel_layer.send)(
                                self.channel_name,
                                {
                                    "type": "send.message",
                                    "text": str(lines_to_process.decode())
                                }
                            )
                            lines_to_process = b''
            client.close()


def _async_raise(tid, exctype):
    """raises the exception, performs cleanup if needed"""
    try:
        tid = ctypes.c_long(tid)
        if not inspect.isclass(exctype):
            exctype = type(exctype)
        res = ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, ctypes.py_object(exctype))
        if res == 0:
            # pass
            raise ValueError("invalid thread id")
        elif res != 1:
            # """if it returns a number greater than one, you're in trouble,
            # and you should call it again with exc=NULL to revert the effect"""
            ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, None)
            raise SystemError("PyThreadState_SetAsyncExc failed")
    except Exception as err:
        print(err)


