import ctypes
import inspect
import json
import re
import subprocess
import threading
import time
from django.views.generic import View
import json

from myproject.settings import BASE_DIR
from myproject.utils import DateEncoder, connectLog
from django.http import HttpResponse

import paramiko
from django.db.models import Q
from django.views.generic import View
from django.http import HttpResponse, FileResponse, StreamingHttpResponse
from ProjectEnvironment.models import ProjectEnvironmentModel

class dowmloadLog(View):
    def post(self,request):
        dto = json.loads(request.body)
        project_id = dto.get("project_id", "")
        environment_id = dto.get("environment_id", "")
        lines = dto.get("lines", 100)
        projectEnvironment = ProjectEnvironmentModel.objects.all().filter(Q(project_id=project_id) & Q(environment_id=environment_id))[0]
        log_path = projectEnvironment.log_path
        if projectEnvironment.log_type == 2:
            log_name = "catalina-" + time.strftime("%Y-%m-%d", time.localtime()) + ".out"
        else:
            log_name = projectEnvironment.log_name
        command = "tail -n "+str(lines)+" "+log_path+"/"+log_name
        out = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, encoding="utf-8")
        c = out.stdout.read()
        # f = "E:\\test_mml\\111.txt"
        # c =open(f, 'rb').read()
        response = HttpResponse(c)
        response['content_type'] = "application/octet-stream"
        response["requestType"] = "file"
        response["Access-Control-Expose-Headers"] = "requestType"
        response['Content-Disposition'] = 'attachment;filename="'+log_name+'"'
        return response

# def topic():
#     local("/jpdata/server/kafka_2.12-2.3.0/bin/kafka-topics.sh --zookeeper 192.168.160.242:2181,192.168.160.109:2181,192.168.160.247:2181 --list")
# def log(t):
#     local("/jpdata/server/kafka_2.12-2.3.0/bin/kafka-console-consumer.sh --bootstrap-server 192.168.160.242:9092,192.168.160.109:9092,192.168.160.247:9092 --topic "+ t)
# def logall(t):
#     local("/jpdata/server/kafka_2.12-2.3.0/bin/kafka-console-consumer.sh --bootstrap-server 192.168.160.242:9092,192.168.160.109:9092,192.168.160.247:9092 --from-beginn
# ing --topic " + t)
#
# def logsize(t):
#     local("/jpdata/server/kafka_2.12-2.3.0/bin/kafka-run-class.sh kafka.tools.GetOffsetShell --broker-list 192.168.160.242:9092,192.168.160.109:9092,192.168.160.247:909
# 2 --topic "+ t +" --time -1")
# def logfrom(t,o):
#     local("/jpdata/server/kafka_2.12-2.3.0/bin/kafka-console-consumer.sh --bootstrap-server 192.168.160.242:9092,192.168.160.109:9092,192.168.160.247:9092 --topic "+ t+
#  " --partition 0 --offset "+o)


class TopicList(View):
    def post(self, request):
        dto = json.loads(request.body)
        topic_list = "%s/log/topic_list.txt" % (BASE_DIR)
        if dto.get('search'):
            searchStr = dto.get('search')
            command = "fab topic |grep -E \"demo|pro\" |grep -v \"web-1\" |grep -v \"redis\" |grep %s  > /tmp/topic_list.txt" % (searchStr)
        else:
            command = "fab topic |grep -E \"demo|pro\" |grep -v \"web-1\" |grep -v \"redis\" > /tmp/topic_list.txt"
        channel, client = connectLog()
        channel.sendall(command + '\n')  # 发送命令
        buff = ''
        try:
            while buff.find('# ') == -1:
                resp = channel.recv(9999)
                buff += resp.decode()
        except Exception as e:
            print("错误:" + str(e))
        channel.sendall('cat /tmp/topic_list.txt' + '\n')  # 发送命令
        buff = ''
        try:
            while buff.find('# ') == -1:
                resp = channel.recv(9999)
                buff += resp.decode()
        except Exception as e:
            print("错误:" + str(e))
        file_handle = open('%s' % (topic_list), 'w')
        buff = buff.replace("\n", '')
        file_handle.write(buff)
        file_handle.close()
        file_handle = open('%s' % (topic_list), mode='r')
        content = file_handle.readlines()
        line = content[1:-1]
        list = []
        for i in range(len(line)):
            line[i] = line[i].rstrip("\n")
            list.append(line)
        file_handle.close()
        channel.close()
        client.close()
        if list == []:
            return HttpResponse(json.dumps({"message": "查询结果为空", "code": 20000}, cls=DateEncoder), content_type='application/json')
        return HttpResponse(json.dumps({"list": list, "code": 20000}, cls=DateEncoder), content_type='application/json')

