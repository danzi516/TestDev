from django.apps import AppConfig


class ProjectpublishConfig(AppConfig):
    name = 'ProjectPublish'
