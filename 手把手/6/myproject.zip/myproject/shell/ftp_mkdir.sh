#!/bin/bash
#产品所属的ftp发布路径，例：/projects/piaojujia/2.8/publish
product_path="$1"
base_path=${product_path%/*}
product=${product_path##*/}
version="$2"
version_path=$product_path"/"$version
publish="publish"
ftp_folder_path=$version_path"/"$publish

if [ ! -n "$1" ];
then
  echo "请输入产品所属的ftp发布路径"
  exit 1
fi

if [ ! -n "$2" ];
then
  echo "请输入产品版本号"
  exit 1
fi

num="1"
date_name=`date +"%Y%m%d"`
folder_name=$date_name"_"$num

upload_ip="172.23.2.1"
ftpuser="ftpuser"
ftppswd="ftpuser"
local_record1="../log/record1.log"

function ftpbasemkdir()
{
ftp -n<<!
open $upload_ip
user $ftpuser $ftppswd
mkdir $base_path
bye
!
}

function ftppromkdir()
{
ftp -n<<!
open $upload_ip
user $ftpuser $ftppswd
cd $base_path
mkdir $product
bye
!
}

function ftpvermkdir()
{
ftp -n<<!
open $upload_ip
user $ftpuser $ftppswd
cd $product_path
mkdir $version
bye
!
}

function ftppublishmkdir()
{
ftp -n<<!
open $upload_ip
user $ftpuser $ftppswd
cd $version_path
mkdir $publish
bye
!
}

function ftpmkdir()
{
ftp -n<<!
open $upload_ip
user $ftpuser $ftppswd
cd $ftp_folder_path
mkdir ${folder_name}
bye
!
}

cd `dirname $0`;
ftpbasemkdir > ${local_record1}
ftppromkdir > ${local_record1}
ftpvermkdir > ${local_record1}
ftppublishmkdir > ${local_record1}

cat /dev/null > ${local_record1}
ftpmkdir > ${local_record1}

while [ `grep -c 'Cannot create a file when that file already exists.' ${local_record1}` -eq 1 ];  do
    if [ `grep -c 'Cannot create a file when that file already exists.' ${local_record1}` -eq 1 ]; then
      let num+=1
      folder_name=$date_name"_"$num
      cd `dirname $0`;
      cat /dev/null > ${local_record1}
      ftpmkdir > ${local_record1}
    fi
done

echo $folder_name
