#!/bin/bash
#ftp服务器的publish目录路径
ftp_folder_path="$1"
#组件工作目录
workspace="$2"
#组件类型
projecttype="$3"
#组件参数
projectparameter="$4"

if [ ! -n "$1" ];
then
  echo "请输入ftp服务器的publish目录路径"
  exit 1
elif [ ! -n "$2" ];
then
  echo "请输入组件工作目录"
  exit 1
elif [ ! -n "$3" ];
then
  echo "请输入组件类型"
  exit 1
elif [ ! -n "$4" ];
then
  echo "请输入组件参数"
  exit 1
fi



upload_ip="172.23.2.1"
ftpuser="ftpuser"
ftppswd="ftpuser"
local_record="record2.log"

function ftpupload()
{
ftp -n<<!
open $upload_ip
user $ftpuser $ftppswd
cd $ftp_folder_path
mkdir $folder_name
cd $folder_name
binary
put $bak_name
bye
!
}

function java_upload() {
  folder_name="java"
  cd $bak_folder_name
  bak_num=$(ls -t |sed -n '1p')
  cd $bak_num
  bak_name=$(ls -t |sed -n '1p')
  ftpupload
}

function php_upload() {
  folder_name="web"
  cd $bak_folder_name
  bak_name=$(ls -t |sed -n '1p')
  ftpupload
}

if [ $projecttype == 1 ]; then
  bak_folder_name=$workspace"/backup/"$projectparameter
  java_upload
  ftp_path=$ftp_folder_path"/"$folder_name
  echo $ftp_path
  echo $bak_name
elif [ $projecttype == 3 ]; then
  bak_folder_name=$workspace"/php_bak/"$projectparameter
  php_upload
  ftp_path=$ftp_folder_path"/"$folder_name
  echo $ftp_path
  echo $bak_name
elif [ $projecttype == 4 ]; then
  bak_folder_name=$workspace"/php_bak/"$projectparameter
  php_upload
  ftp_path=$ftp_folder_path"/"$folder_name
  echo $ftp_path
  echo $bak_name
fi
