#!/bin/bash

#组件名
project_name="$1"
#pod名
podname="$2"
#应用发布目录
dir_publish="$3"
#组件工作目录
project_workspace="$4"
#包名
version_name="$5"
#打包类型
version_type="$6"
#ftp目录路径
ftp_path="$7"
#不同的服务器ip
hostname="$8"
#应用配置目录相对路径
publish_conf="$9"
#配置文件名
file_conf="${10}"

upload_ip="172.23.2.1"
ftpuser="ftpuser"
ftppswd="ftpuser"
local_record="../log/record_java.log"



if [ ! -n "$1" ];
then
  echo "请输入组件名"
  exit 1
elif [ ! -n "$2" ];
then
  echo "请输入pod名"
  exit 1
elif [ ! -n "$3" ];
then
  echo "请输入发布目录路径"
  exit 1
elif [ ! -n "$4" ];
then
  echo "请输入工作目录路径"
  exit 1
elif [ ! -n "$5" ];
then
  echo "请输入包名"
  exit 1
elif [ ! -n "$6" ];
then
  echo "请输入打包类型"
  exit 1
elif [ ! -n "$7" ];
then
  echo "请输入ftp路径"
  exit 1
fi

file_conf=$project_workspace"/"$hostname"/"$file_conf
publish_floder=$dir_publish"/"$project_name
publish_conf=$dir_publish"/"$project_name"/"$publish_conf
bak_name=`date +"%Y%m%d%H%M"`
bak_full_folder=$project_workspace"/backup/full/"
bak_full_folder_name=$bak_full_folder$bak_name
bak_incremental_folder_name=$project_workspace"/backup/incremental/"$bak_name
file_home_update=$project_workspace"/update"
file_suffix=${version_name#*.}

cd $project_workspace
if [ ! -d $file_home_update ]; then
  mkdir -p $file_home_update
fi

#从ftp上更新
function ftpget()
{
ftp -n<<!
open $upload_ip
user $ftpuser $ftppswd
binary
hash
cd $ftp_path
lcd $file_home_update
get $version_name
close
bye
!
}

cd `dirname $0`;
cat /dev/null > ${local_record}
ftpget > ${local_record}

if [ `grep -c 'The system cannot find the file specified.' ${local_record}` -eq 1 ]; then
  echo "更新包不存在"
  exit 1
fi


cd $file_home_update
if [ -d $project_name ]; then
  rm -rf $project_name
fi

function full() {
  if [ -d $bak_full_folder ]; then
    rm -rf $bak_full_folder
  fi
  if [ -d $publish_floder ]; then
    rm -rf $publish_floder
  fi
  mkdir $project_name
  mkdir -p $bak_full_folder_name
  unzip $version_name -d $project_name
  mv $project_name $dir_publish
  mv $version_name $bak_full_folder_name
  if [ -f $file_conf ]; then
    cp -f $file_conf $publish_conf
  fi
  return 0
}

function incremental() {
  mkdir $project_name
  mkdir -p $bak_incremental_folder_name
  unzip $version_name
  cp -r $project_name $dir_publish
  mv $version_name $bak_incremental_folder_name
  return 0
}

if [ $version_type == 1 ];then
  echo "发布包为全量包"
  if [ $file_suffix == war ];then
    full
  else
    echo "下载的文件不是全量包"
    exit 1
  fi
elif [ $version_type == 2 ];then
  echo "发布包为增量包"
  if [ $file_suffix == zip ];then
    incremental
  else
    echo "下载的文件不是增量包"
    exit 1
  fi
fi

kubectl get pods -n kube-system |grep ^$podname | awk '{print $1}' | xargs kubectl delete pods -n kube-system

exit 0