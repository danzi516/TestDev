#!/bin/bash

#组件名
project_name="$1"
#打包的中间参数
parameter="$2"
#应用发布目录
dir_publish="$3"
#组件工作目录
project_workspace="$4"
#开发打包服务器的生成路径
dev_path="$5"
#组件类型
project_type="$6"
#容器名称
podname="$7"
#开发打包服务器地址
hostname="172.23.50.21"

if [ ! -n "$1" ];
then
  echo "请输入组件名"
  exit 1
elif [ ! -n "$2" ];
then
  echo "请输入参数名"
  exit 1
elif [ ! -n "$3" ];
then
  echo "请输入发布目录路径"
  exit 1
elif [ ! -n "$4" ];
then
  echo "请输入工作目录路径"
  exit 1
elif [ ! -n "$5" ];
then
  echo "请输入开发服务器打包路径"
  exit 1
elif [ ! -n "$6" ];
then
  echo "请输入组件类型"
  exit 1
fi

project_workspace_update=$project_workspace"/php_update"
project_workspace_update_parameter=$project_workspace_update"/"$parameter
project_workspace_bak=$project_workspace"/php_bak/"$parameter
file_dev_name=${project_name%-*}
dir_test_update_tar=$(ssh root@$hostname "cd $dev_path;ls -t *.tar.gz |sed -n '1p'")
dir_test_update_txt=$(cd $project_workspace_update_parameter;ls -t *.txt |sed -n '1p')
dir_file_update_dev1=$project_workspace_update_parameter"/"$file_dev_name"/*"
dir_file_update_dev2=$project_workspace_update_parameter"/"$project_name"/*"
dir_nginx_www_name=$dir_publish"/"$project_name

cd $project_workspace
if [ ! -d $project_workspace_update ]; then
  mkdir -p $project_workspace_update
fi
if [ ! -d $project_workspace_bak ]; then
  mkdir -p $project_workspace_bak
fi

cd $project_workspace_update
if [ -d $project_workspace_update_parameter ]; then
  rm -rf $project_workspace_update_parameter
fi
mkdir -p $project_workspace_update_parameter

#复制打包服务器的更新包到本机
scp root@$hostname:$dev_path"/"$dir_test_update_tar $project_workspace_update_parameter

#解压更新包并拷贝到发布目录
cd $project_workspace_update_parameter
tar -zxvf $dir_test_update_tar

if [ $project_type == 3 ] && [ -d $file_dev_name ] && [ -d $dir_nginx_www_name ]; then
  cp -r $dir_file_update_dev1 $dir_nginx_www_name
elif [ $project_type == 3 ] && [ -d $file_dev_name ] && [ ! -d $dir_nginx_www_name ]; then
  mkdir -p $dir_nginx_www_name
  cp -r $dir_file_update_dev1 $dir_nginx_www_name
elif [ $project_type == 3 ] && [ ! -d $file_dev_name ] && [ -d $dir_nginx_www_name ]; then
  cp -r $dir_file_update_dev2 $dir_nginx_www_name
elif [ $project_type == 3 ] && [ ! -d $file_dev_name ] && [ ! -d $dir_nginx_www_name ]; then
  mkdir -p $dir_nginx_www_name
  cp -r $dir_file_update_dev2 $dir_nginx_www_name
elif [ $project_type == 4 ] && [ -d $file_dev_name ]; then
  cp -r $dir_file_update_dev1 $dir_publish
elif [ $project_type == 4 ] && [ ! -d $file_dev_name ]; then
  cp -r $dir_file_update_dev2 $dir_publish
else
  exit 1
fi

#移动更新包到备份目录
mv $dir_test_update_tar $project_workspace_bak

if [ -n "$podname" ];
then
  kubectl get pods -n kube-system |grep ^$podname | awk '{print $1}' | xargs kubectl delete pods -n kube-system
  echo "########################"
  echo "更新包名为："
  echo $dir_test_update_tar
  exit 0
fi

echo "########################"
echo "更新包名为："
echo $dir_test_update_tar
exit 0
