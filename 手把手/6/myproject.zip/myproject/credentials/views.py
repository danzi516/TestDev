import json

from django.views.generic import View
# Create your views here.
from django.http import HttpResponse

#数据库操作
#添加数据
# from myproject.BaseDao import BaseDAO
from myproject.utils import DateEncoder, ModelsUtil, Encrypted_text
from credentials.models import CredentialsModel


class InsertRecord(View):
    def post(self,request):
        dto = json.loads(request.body)
        type = dto.get("type","")
        username = dto.get("username", "")
        password = dto.get("password", "")
        password = Encrypted_text(password)
        name = dto.get("name", "")
        Record = CredentialsModel(type=type, username=username,password=password,name=name)
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
#删除数据
class DeleteById(View):
    def post(self,request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = CredentialsModel(id=id)
        Record.delete()
        return  HttpResponse(json.dumps({"code":20000}),content_type="application/json")

#修改数据
class UpdateBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = CredentialsModel.objects.get(id=id)
        if dto.get('type'):
            Record.type = dto.get('type')
        if dto.get('username'):
            Record.username = dto.get('username')
        if dto.get('password'):
            Record.password = Encrypted_text(dto.get('password'))
        if dto.get('name'):
            Record.name = dto.get('name')
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

#查询所有
class SelectAll(View):
    def post(self,request):
        listRes = CredentialsModel.objects.values()
        listRes = list(listRes)
        return  HttpResponse(json.dumps({"modelList": listRes, "code": 20000},cls=DateEncoder),content_type="application/json")

#根据条件查询
class SelectBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        recordList = CredentialsModel.objects.values()
        if dto.get('id'):
            recordList = recordList.filter(id=dto.get('id'))
        if dto.get('type'):
            recordList = recordList.filter(type=dto.get('type'))
        if dto.get('username'):
            recordList = recordList.filter(username=dto.get('username'))
        if dto.get('password'):
            recordList = recordList.filter(password=dto.get('password'))
        if dto.get('name'):
            recordList = recordList.filter(name=dto.get('name'))
        listRes = list(recordList)
        return HttpResponse(json.dumps({"modelList": listRes, "code": 20000}, cls=DateEncoder),content_type="application/json")

#分页查询
class SelectByPage(View):
    def post(self,request):
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1) * limit
        sort = dto.get('sort')
        order = dto.get('order')
        length = len(CredentialsModel.objects.all())
        targets = CredentialsModel.objects.all()
        if not limit:
            targets = CredentialsModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        for row in targets:
            data_set.append(ModelsUtil(CredentialsModel).toDict(row))
        return HttpResponse(json.dumps({"rows":data_set,"total":length,"code":20000}), content_type='application/json')

