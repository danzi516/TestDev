from django.db import models

# Create your models here.
class CredentialsModel(models.Model):
    id = models.AutoField(primary_key=True)
    type = models.IntegerField(max_length=11)
    username = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    class Meta:
        db_table = "credentials"

