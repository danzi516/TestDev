from django.apps import AppConfig


class CredentialsConfig(AppConfig):
    name = 'credentials'
