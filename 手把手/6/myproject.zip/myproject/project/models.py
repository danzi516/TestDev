from django.db import models


# Create your models here.
from user.model import userModel


class projectModel(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    type = models.IntegerField(max_length=11)
    status = models.IntegerField(max_length=11)
    creator_id = models.IntegerField
    create_time = models.DateTimeField(auto_now_add=True)
    workspace = models.CharField(max_length=255)
    publish_conf = models.CharField(max_length=255)
    SVNaddress = models.CharField(max_length=255)
    SVNfolder = models.CharField(max_length=255)
    credentials_id = models.IntegerField(max_length=11)
    start_time = models.DateTimeField(auto_now_add=False)
    close_id = models.IntegerField
    close_time = models.DateTimeField(auto_now_add=False)
    creator = models.ForeignKey(userModel, related_name='Project_CreateUser', on_delete=models.CASCADE)
    close = models.ForeignKey(userModel, related_name='Project_CloseUser', on_delete=models.CASCADE)
    class Meta:
        db_table = "project"

