from django.urls import path
from project import views
urlpatterns = [
    path('InsertRecord', views.InsertRecord.as_view(), name='save'), #name 可以用于在 templates, models, views ……中得到对应的网址，相当于“给网址取了个名字”，只要这个名字不变，网址变了也能通过名字获取到
    # path('DeleteById', views.DeleteById.as_view()),
    path('UpdateBySelective', views.UpdateBySelective.as_view()),
    path('SelectAll', views.SelectAll.as_view()),
    path('SelectBySelective', views.SelectBySelective.as_view()),
    path('SelectByPage', views.SelectByPage.as_view()),
    path('SelectByPageByPart', views.SelectByPageByPart.as_view()),
    path('SelectByPageByDepend', views.SelectByPageByDepend.as_view()),
    path('SvnCheckOut', views.SvnCheckOut.as_view()),
    path('AddTestWorkspace', views.AddTestWorkspace.as_view()),
    path('TestProjectList', views.TestProjectList.as_view()),
    path('RestartPod', views.RestartPod.as_view()),
    path('TestJavaProjectPublish', views.TestJavaProjectPublish.as_view()),
    path('TestProjectService', views.TestProjectService.as_view()),
    path('BulidJavaProject', views.BulidJavaProject.as_view()),
]