import datetime
import os
import re
import subprocess
import threading
import time

from django.http import HttpResponse

from myproject.settings import BASE_DIR
from ProjectBulid.models import ProjectBulidModel
from ProjectEnvironment.models import ProjectEnvironmentModel
from PhpConfiguration.models import PhpConfigurationModel
from django.views.generic import View

from myproject.utils import DateEncoder, ModelsUtil, Decrypted_text
from environment.models import EnvironmentModel
from project.models import projectModel
from credentials.models import CredentialsModel
import json
from django.db.models import Q
from myproject import rest_searilizers

def duplicateVerify(str):
    Record = projectModel.objects.filter(Q(name=str) & Q(status=1)).first()
    if Record is not None:
        return False
    else:
        return True

#数据库操作
#添加数据
class InsertRecord(View):
    def post(self,request):
        operateId = request.META['HTTP_X_TOKEN']  #取得操作员id
        dto = json.loads(request.body)
        name = dto.get("name","")
        description = dto.get("description","")
        type = dto.get("type","")
        status = dto.get("status","")
        workspace = dto.get("workspace","")
        publish_conf = dto.get("publish_conf","")
        SVNaddress = dto.get("SVNaddress","")
        SVNfolder = dto.get("SVNfolder","")
        credentials_id = dto.get("credentials_id",None)
        creator_id = operateId
        Record = projectModel(name=name,description=description,type=type,status=status,
                              workspace=workspace,publish_conf=publish_conf,SVNaddress=SVNaddress,
                              SVNfolder=SVNfolder,credentials_id=credentials_id,creator_id=creator_id)
        if(duplicateVerify(name)):
            Record.save()
            if(type==3):
                PhpConfigurationlist = dto.get("PhpConfiguration_project", "")
                for item in PhpConfigurationlist:
                    project_id= Record.id
                    parameter = item['parameter']
                    dev_path = item['dev_path']
                    PhpConfiguration = PhpConfigurationModel(project_id=project_id,parameter=parameter,dev_path=dev_path)
                    PhpConfiguration.save()
            return HttpResponse(json.dumps({"code": 20000,"id":Record.id}), content_type="application/json")
        else:
            return HttpResponse(json.dumps({"message": '组件已存在', "code": 10002}), content_type="application/json")

#删除数据
class DeleteById(View):
    def post(self,request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = projectModel(id=id)
        Record.delete()
        return  HttpResponse(json.dumps({"code":20000}),content_type="application/json")

#修改数据
class UpdateBySelective(View):
    def post(self,request):
        operateId = request.META['HTTP_X_TOKEN']  # 取得操作员id
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = projectModel.objects.get(id=id)
        if dto.get('name'):
            name = dto.get('name')
            if(name != Record.name):
                if (duplicateVerify(name)==False):
                    return HttpResponse(json.dumps({"code": 10002, "message": "组件名重复"}), content_type="application/json")
            Record.name = dto.get('name')
        if dto.get('description'):
            Record.description = dto.get('description')
        if dto.get('type'):
            Record.type = dto.get('type')
        if dto.get('status'):
            Record.status = dto.get('status')
            if Record.status == 2:
                Record.close_id = operateId
                Record.close_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            elif Record.status == 1:
                Record.close_id = None
                Record.close_time = None
        if dto.get('workspace'):
            Record.workspace = dto.get('workspace')
        if dto.get('publish_conf'):
            Record.publish_conf = dto.get('publish_conf')
        Record.SVNaddress = dto.get('SVNaddress','')
        # if dto.get('SVNaddress'):
        #     Record.SVNaddress = dto.get('SVNaddress')
        if dto.get('SVNfolder'):
            Record.SVNfolder = dto.get('SVNfolder')
        Record.credentials_id = dto.get("credentials_id", None)
        # if dto.get('credentials_id'):
        #     Record.credentials_id = dto.get('credentials_id')
        if dto.get('start_time'):
            Record.start_time = dto.get('start_time')
        Record.save()
        if (Record.type == 3):
            PhpConfigurationlist = dto.get("PhpConfiguration_project", "")
            project_id = id
            PhpConfigurations = PhpConfigurationModel.objects.filter(project_id=project_id)
            if PhpConfigurations:
                    PhpConfigurations.delete()
            for item in PhpConfigurationlist:
                project_id = Record.id
                parameter = item['parameter']
                dev_path = item['dev_path']
                PhpConfiguration = PhpConfigurationModel(project_id=project_id, parameter=parameter, dev_path=dev_path)
                PhpConfiguration.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

#查询所有
class SelectAll(View):
    def post(self,request):
        listRes = projectModel.objects.values()
        listRes = list(listRes)
        return  HttpResponse(json.dumps({"modelList": listRes, "code": 20000},cls=DateEncoder),content_type="application/json")

#根据条件查询
class SelectBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        recordList = projectModel.objects.values()
        if dto.get('id'):
            recordList = recordList.filter(id=dto.get('id'))
        if dto.get('name'):
            recordList = recordList.filter(name=dto.get('name'))
        if dto.get('description'):
            recordList = recordList.filter(description=dto.get('description'))
        if dto.get('type'):
            recordList = recordList.filter(type=dto.get('type'))
        if dto.get('status'):
            recordList = recordList.filter(status=dto.get('status'))
        if dto.get('workspace'):
            recordList = recordList.filter(workspace=dto.get('workspace'))
        if dto.get('publish_conf'):
            recordList = recordList.filter(publish_conf=dto.get('publish_conf'))
        if dto.get('SVNaddress'):
            recordList = recordList.filter(SVNaddress=dto.get('SVNaddress'))
        if dto.get('creator_id'):
            recordList = recordList.filter(creator_id=dto.get('creator_id'))
        if dto.get('create_time'):
            recordList = recordList.filter(create_time=dto.get('create_time'))
        if dto.get('start_time'):
            recordList = recordList.filter(start_time=dto.get('start_time'))
        if dto.get('close_id'):
            recordList = recordList.filter(close_id=dto.get('close_id'))
        if dto.get('close_time'):
            recordList = recordList.filter(close_time=dto.get('close_time'))
        listRes = list(recordList)
        return HttpResponse(json.dumps({"modelList": listRes, "code": 20000}, cls=DateEncoder),content_type="application/json")

#分页查询全部组件
class SelectByPage(View):
    def post(self,request):
        userId = request.META['HTTP_X_TOKEN']
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1) * limit
        sort = dto.get('sort')
        order = dto.get('order')
        targets = projectModel.objects.all()
        if dto.get('search'):
            search = dto.get('search')
            targets = projectModel.objects.all().filter(Q(name__icontains=search)|Q(description__icontains=search))
        length = len(targets)
        if not limit:
            targets = projectModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        listRes = rest_searilizers.ProjectSerializer(targets, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"rows":data_set,"total":length,"code":20000},cls=DateEncoder), content_type='application/json')

#分页查询java依赖包以外的全部组件
class SelectByPageByPart(View):
    def post(self,request):
        userId = request.META['HTTP_X_TOKEN']
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1) * limit
        sort = dto.get('sort')
        order = dto.get('order')
        # targets = projectModel.objects.all()
        targets = projectModel.objects.exclude(type=2)
        if dto.get('search'):
            search = dto.get('search')
            targets = projectModel.objects.all().filter(Q(name__icontains=search)|Q(description__icontains=search))
        length = len(targets)
        if not limit:
            targets = projectModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        listRes = rest_searilizers.ProjectSerializer(targets, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"rows":data_set,"total":length,"code":20000},cls=DateEncoder), content_type='application/json')

#分页查询java依赖包的组件
class SelectByPageByDepend(View):
    def post(self,request):
        userId = request.META['HTTP_X_TOKEN']
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1) * limit
        sort = dto.get('sort')
        order = dto.get('order')
        # targets = projectModel.objects.all()
        targets = projectModel.objects.filter(type=2)
        if dto.get('search'):
            search = dto.get('search')
            targets = projectModel.objects.all().filter(Q(name__icontains=search)|Q(description__icontains=search))
        length = len(targets)
        if not limit:
            targets = projectModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        listRes = rest_searilizers.ProjectSerializer(targets, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"rows":data_set,"total":length,"code":20000},cls=DateEncoder), content_type='application/json')

#创建工作目录
class AddTestWorkspace(View):
    def post(self,request):
        dto = json.loads(request.body)
        if dto.get('name'):
            name = dto.get('name')
            workname = "/jpdata/test_workspace/" + name
            Record = projectModel.objects.get(Q(name=name) & Q(status=1))
            Record.workspace = workname
            # os.system('mkdir -p %s' % (workname))
            ret = os.system('mkdir -p %s' % (workname))
            if ret == 0:
                 Record.save()
                 return HttpResponse(json.dumps({"workspace": workname, "code": 20000}), content_type="application/json")
        return HttpResponse(json.dumps({"code": 20000, "message": "创建工作目录失败"}), content_type="application/json")

#svncheckout
class SvnCheckOut(View):
    def post(self,request):
        dto = json.loads(request.body)
        project_id = dto.get('project_id')
        credentials_id = dto.get('credentials_id')
        Record1 = projectModel.objects.get(id=project_id)
        workspace = Record1.workspace
        SVNaddress = Record1.SVNaddress
        command = "svn co --non-interactive --trust-server-cert %s %s --username %s --password %s"
        if project_id is None or project_id == '':
            return HttpResponse(json.dumps({"message": "未选择组件", "code": 10002}), content_type="application/json")
        elif SVNaddress is not None and SVNaddress != '' and credentials_id is not None and credentials_id != '':
            Record2 = CredentialsModel.objects.get(id=credentials_id)
            username = Record2.username
            password = Record2.password
            password = Decrypted_text(password)
            if username is None or username == '':
                return HttpResponse(json.dumps({"message": "凭证不存在", "code": 10002}), content_type="application/json")
            folder = SVNaddress.split("/")
            svnfolder = folder[-1]
            SVNfolder = workspace + "/" + svnfolder
            os.system('rm -rf %s' %(SVNfolder))
            os.system('mkdir %s' % (SVNfolder))
            Record1.SVNfolder = SVNfolder
            Record1.creator_id = credentials_id
            cmd = command % (SVNaddress, SVNfolder, username, password)
            # ret = os.system(command % (SVNaddress,SVNfolder,username,password))
            # ret = os.popen(command % (SVNaddress,SVNfolder,username,password))
            ret = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")
            msg_out = ret.stdout.read()
            msg_err = ret.stderr.read()
            svncode1 = "E170013"
            svncode2 = "E170000"
            svn_ret1 = msg_err.find(svncode1)
            svn_ret2 = msg_err.find(svncode2)
            # msg_out.close()
            # msg_err.close()
            ret.terminate()
            if not svn_ret1 == -1:
                return HttpResponse(json.dumps({"message": "认证失败", "code": 10002}), content_type="application/json")
            elif not svn_ret2 == -1:
                return HttpResponse(json.dumps({"message": "svn目录不存在", "code": 10002}), content_type="application/json")
            else:
                svn_version = re.findall(r"\d+\.?\d*", msg_out[-12:-1])
                Record1.save()
                return HttpResponse(json.dumps({"message": "svn取出版本：" + svn_version[0], "code": 20000}), content_type="application/json")
        elif SVNaddress is None or SVNaddress == '':
            if credentials_id is None or credentials_id == '':
                Record1.credentials_id = None
            Record1.SVNfolder = ''
            Record1.save()
            return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

#查询测试服务器pod列表
class TestProjectList(View):
    def post(self,request):
        dto = json.loads(request.body)
        log_path = "%s/log/list_project.txt" % (BASE_DIR)
        if dto.get('search'):
            searchStr = dto.get('search')
            os.system('kubectl get pods -n kube-system --sort-by=\'{.status.startTime}\'|grep -v \'calico\'|grep '+searchStr+ '|awk \'{print $1,$3,$5}\' >%s' %(log_path))
        else:
            os.system('kubectl get pods -n kube-system --sort-by=\'{.status.startTime}\' |grep -v \'calico\'|awk \'{if(NR!=1) print $1,$3,$5}\' >%s' %(log_path))
        time.sleep(1)
        file = open("%s" % (log_path), 'r')
        file_lines = file.readlines()
        labels = []
        index = 0
        for line in reversed(file_lines):
            line = line.strip()  # 参数为空时，默认删除开头、结尾处空白符（包括'\n', '\r',  '\t',  ' ')
            formLine = line.split(' ')
            labels.append((formLine))
            index += 1
        file.close()
        file_lines.clear()
        return HttpResponse(json.dumps({"code": 20000,"data":labels}), content_type="application/json")

#测试服务器根据pod查出对应的地址和端口列表
class TestProjectService(View):
    def post(self, request):
        dto = json.loads(request.body)
        podname = ''
        if dto.get('sername'):
            sername = dto.get('sername')
            cmd1 = "kubectl get pods %s -n kube-system -o yaml --export |grep app:" % (sername)
            out1 = subprocess.Popen(cmd1, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")
            out1_err = out1.stderr.read()
            out1_err = out1_err.find(sername)
            if not out1_err == -1:
                out1.stderr.close()
                return HttpResponse(json.dumps({"message": "%s已变更或不存在，请重新查询" % (sername), "code": 10002}), content_type="application/json")
            else:
                podname = str(out1.stdout.read().splitlines()[0]).split("app:")[1].strip().split("'")[0]
                out1.stderr.close()
        elif dto.get('podname'):
            podname = dto.get('podname')
        elif podname == '':
            return HttpResponse(json.dumps({"message": "容器名为空，请先添加容器名", "code": 10002}),content_type="application/json")
        cmd2 = "kubectl get service %s -n kube-system -o yaml --export |grep annotations |grep spec" % (podname)
        out2 = subprocess.Popen(cmd2, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")
        out2_err = out2.stderr.read()
        out2_err = out2_err.find(podname)
        if not out2_err == -1:
            out2.stderr.close()
            return HttpResponse(json.dumps({"message": "%s不存在，请确认" % (podname), "code": 10002}),content_type="application/json")
        else:
            out2.stderr.close()
            ServiceList = str(out2.stdout.read()).lstrip("b'").rstrip("'").replace("\\n", "")
            if ServiceList is None or ServiceList == '':
                cmd3 = "kubectl get service %s -n kube-system -o json" % (podname)
                out3 = subprocess.Popen(cmd3, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")
                out3_err = out3.stderr.read().find(podname)
                if not out3_err == -1:
                    out3.stderr.close()
                    return HttpResponse(json.dumps({"message": "%s不存在，请确认" % (podname), "code": 10002}),content_type="application/json")
                ServiceList = out3.stdout.read()
                ServiceList = json.loads(ServiceList)
                out3.stderr.close()
                out3.stdout.close()
                return HttpResponse(json.dumps({"message": ServiceList, "code": 20000}),content_type="application/json")
            ServiceList = json.loads(ServiceList)
            out2.stdout.close()
            return HttpResponse(json.dumps({"message": ServiceList, "code": 20000}), content_type="application/json")

#重启测试服务器选定的pod
class RestartPod(View):
    def post(self,request):
        dto = json.loads(request.body)
        podname = dto.get('pod', '')
        if podname:
            cmd1 = "kubectl get pods -n kube-system |grep -v 'calico'|grep ^%s | awk '{print $1}'"
            cmd2 = "kubectl delete pods %s -n kube-system"
            ret = os.popen(cmd1 % (podname))
            msg = str(ret.read()).strip()
            if msg is None or msg == '':
                ret.close()
                return HttpResponse(json.dumps({"message": "%s已变更，请重新查询后重启" % (podname), "code": 10002}), content_type="application/json")
            os.system(cmd2 % (msg))
            ret.close()
            return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
        elif podname is None or podname == '':
            return HttpResponse(json.dumps({"message": "必须选择一个pod才能重启", "code": 10002}), content_type="application/json")
        return HttpResponse(json.dumps({"code": 10002}), content_type="application/json")

#（临时使用）测试服务器发布java应用，environment_id写死测试服务器
class TestJavaProjectPublish(View):
    def post(self, request):
        dto = json.loads(request.body)
        project_id = dto.get('project_id')
        environment_id = dto.get('environment_id')
        ftp_path = dto.get('ftp_path')
        version_name = dto.get('version_name')
        version_type = dto.get('version_type')
        Record1 = projectModel.objects.get(id=project_id)
        project_name = Record1.name
        project_workspace = Record1.workspace
        publish_conf = Record1.publish_conf
        Record2 = ProjectEnvironmentModel.objects.get(Q(project_id=project_id) & Q(environment_id=environment_id))
        if(Record2.podname):
            podname = Record2.podname
        else:
            return HttpResponse(json.dumps({"code": 10002}), content_type="application/json")
        dir_publish = Record2.dir_publish
        file_conf = Record2.file_conf
        # publish_conf = Record2.publish_confpublish_conf
        Record3 = EnvironmentModel.objects.get(id=environment_id)
        hostname = Record3.hostname
        command = str(BASE_DIR) + "/shell/java_publish.sh %s %s %s %s %s %s %s %s %s %s"
        # os.system(command % (project_name,podname,dir_publish,project_workspace,version_name,version_type,ftp_path,hostname,publish_conf,file_conf))
        ret = os.popen(command % (project_name,podname,dir_publish,project_workspace,version_name,version_type,ftp_path,hostname,publish_conf,file_conf))
        msg = ret.read()
        ret.close()
        if not msg.find("更新包不存在") == -1:
            return HttpResponse(json.dumps({"message": "更新包不存在", "code": 10002}), content_type="application/json")
        elif not msg.find("下载的文件不是全量包") == -1:
            return HttpResponse(json.dumps({"message": "不是全量包", "code": 10002}), content_type="application/json")
        elif not msg.find("下载的文件不是增量包") == -1:
            return HttpResponse(json.dumps({"message": "不是增量包", "code": 10002}), content_type="application/json")
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

#java组件打包
class BulidJavaProject(View):
    def post(self, request):
        dto = json.loads(request.body)
        operateId = request.META['HTTP_X_TOKEN']  # 取得操作员id
        project_id = dto.get('project_id')
        project_type = dto.get('type')
        version_type = dto.get('version_type', '')
        if project_type != 1 and project_type != 2:
            return HttpResponse(json.dumps({"message": "组件类型错误", "code": 10002}),content_type="application/json")
        elif version_type != 1 and version_type != 2 and version_type != '':
            return HttpResponse(json.dumps({"message": "打包类型错误", "code": 10002}), content_type="application/json")
        Record1 = projectModel.objects.get(id=project_id)
        project_name = Record1.name
        workspace = Record1.workspace
        SVNaddress = Record1.SVNaddress
        SVNfolder = Record1.SVNfolder
        credentials_id = Record1.credentials_id
        if workspace is None or workspace == '':
            return HttpResponse(json.dumps({"message": "组件工作空间不存在，请重新配置", "code": 10002}), content_type="application/json")
        elif SVNaddress is None or SVNaddress == '':
            return HttpResponse(json.dumps({"message": "svn地址未配置，请重新配置", "code": 10002}),content_type="application/json")
        elif SVNfolder is None or SVNfolder == '':
            return HttpResponse(json.dumps({"message": "svn地址未配置，请重新配置", "code": 10002}),content_type="application/json")
        elif credentials_id is None or credentials_id == '':
            return HttpResponse(json.dumps({"message": "svn凭证未关联，请重新配置", "code": 10002}),content_type="application/json")
        Record2 = CredentialsModel.objects.get(id=credentials_id)
        username = Record2.username
        password = Record2.password
        password = Decrypted_text(password)
        zipname = self.zipName(project_name)
        name = ''
        if project_type == 1 and version_type == 1:
            name = project_name + ".war"
        elif project_type == 1 and version_type == 2:
            name = zipname
        elif project_type == 2:
            name = project_name + ".jar"
        Record3 = ProjectBulidModel(name=name, project_id=project_id, type=project_type, status=1, create_uid=operateId)
        Record3.save()
        bulid_id = Record3.id
        #启动线程，更新代码后打包
        t1 = threading.Thread(target=self.project_run,args=(SVNfolder, username, password, bulid_id, zipname, project_type, version_type))
        t1.start()
        return HttpResponse(json.dumps({"message": "开始执行", "code": 20000}), content_type="application/json")
    #更新代码后打包
    def project_run(self, SVNfolder, username, password, bulid_id, zipname, project_type, version_type):
        status = self.project_update(SVNfolder, username, password, bulid_id)
        if status == 3:
            self.project_bulid(SVNfolder, zipname, project_type, version_type, bulid_id)
    #更新svn代码
    def project_update(self,SVNfolder, username, password, bulid_id):
        cmd_svn_up = "svn up --non-interactive --trust-server-cert %s --username %s --password %s" % (SVNfolder, username, password)
        ret_svn = subprocess.Popen(cmd_svn_up, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,encoding="utf-8")
        msg_out = ret_svn.stdout.read()
        msg_err = ret_svn.stderr.read()
        svn_code1 = "E170013"
        svn_code2 = "E155007"
        svn_ret1 = msg_err.find(svn_code1)
        svn_ret2 = msg_err.find(svn_code2)
        ret_svn.stdout.close()
        ret_svn.stderr.close()
        Record4 = ProjectBulidModel.objects.get(id=bulid_id)
        if not svn_ret1 == -1:
            info = "认证失败，svn_code：" + svn_code1
            status = 2
        elif not svn_ret2 == -1:
            info = "svn目录错误，svn_code：" + svn_code2
            status = 2
        else:
            svn_version = re.findall(r"\d+\.?\d*", str(msg_out[-12:-1]))
            info = "代码更新成功，svn版本号：" + svn_version[0]
            status = 3
            Record4.SVNversion = svn_version[0]
        Record4.info = info
        Record4.status = status
        Record4.save()
        return status
    #java组件打包
    def project_bulid(self, SVNfolder, zipname, project_type, version_type, bulid_id):
        cmd1_war = "mvn -Dmaven.test.failure.ignore=true clean package war:war"
        cmd2_zip = "mvn -Dmaven.test.failure.ignore=true -DzipName=%s clean package -P zip" % (zipname)
        cmd3 = "mvn clean install"
        Record4 = ProjectBulidModel.objects.get(id=bulid_id)
        svn_info = Record4.info
        cmd = "cd %s" % (SVNfolder)
        if project_type == 1 and version_type == 1:
            cmd = cmd + "&&" + cmd1_war
            ret = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, encoding="utf-8")
            msg_out = str(ret.stdout.read())
            msg_out = msg_out.replace("[1;34m", "").replace("[1;33m", "").replace("[1;32m", "")
            msg_out = msg_out.replace("[0;36m", "").replace("[36m", "").replace("[0;32m", "")
            msg_out = msg_out.replace("[1m", "").replace("[0;1m", "").replace("[m", "")
            ret.stdout.close()
            sucess_info = "SUCCESS"
            err_info = "ERROR"
            bulid_err_info = msg_out.find(err_info)
            bulid_sucess_info = msg_out.find(sucess_info)
            info = svn_info + " " + msg_out
            if bulid_err_info != -1:
                status = 5
            elif bulid_sucess_info != -1 and bulid_err_info == -1:
                status = 4
            else:
                info = svn_info + "打包超时"
                status = 5
            Record4.info = info
            Record4.status = status
            Record4.save()
        elif project_type == 1 and version_type == 2:
            cmd = cmd + "&&" + cmd2_zip
            ret = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, encoding="utf-8")
            msg_out = str(ret.stdout.read())
            msg_out = msg_out.replace("[1;34m", "").replace("[1;33m", "").replace("[1;32m", "")
            msg_out = msg_out.replace("[0;36m", "").replace("[36m", "").replace("[0;32m", "")
            msg_out = msg_out.replace("[1m", "").replace("[0;1m", "").replace("[m", "")
            ret.stdout.close()
            sucess_info = "SUCCESS"
            err_info = "ERROR"
            bulid_err_info = msg_out.find(err_info)
            bulid_sucess_info = msg_out.find(sucess_info)
            info = svn_info + " " + msg_out
            if bulid_err_info != -1:
                status = 5
            elif bulid_sucess_info != -1 and bulid_err_info == -1:
                status = 4
            else:
                info = svn_info + "打包超时"
                status = 5
            Record4.info = info
            Record4.status = status
            Record4.save()
        elif project_type == 2:
            cmd = cmd + "&&" + cmd3
            ret = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, encoding="utf-8")
            msg_out = str(ret.stdout.read())
            msg_out = msg_out.replace("[1;34m", "").replace("[1;33m", "").replace("[1;32m", "")
            msg_out = msg_out.replace("[0;36m", "").replace("[36m", "").replace("[0;32m", "")
            msg_out = msg_out.replace("[1m", "").replace("[0;1m", "").replace("[m", "")
            ret.stdout.close()
            sucess_info = "SUCCESS"
            err_info = "ERROR"
            bulid_err_info = msg_out.find(err_info)
            bulid_sucess_info = msg_out.find(sucess_info)
            info = svn_info + " " + msg_out
            if bulid_err_info != -1:
                status = 5
            elif bulid_sucess_info != -1 and bulid_err_info == -1:
                status = 4
            else:
                info = svn_info + "打包超时"
                status = 5
            Record4.info = info
            Record4.status = status
            Record4.save()
    #java增量包命名
    def zipName(self, project_name):
        today = datetime.date.today().strftime("%Y%m%d")
        version_name = project_name + "_update_" + today + "_"
        Record2 = ProjectBulidModel.objects.filter(name__contains=version_name)
        if Record2.first():
            out = Record2.order_by("id").last()
            out = out.split('_')[-1]
            out = int(out)
            bulid_num = str(out + 1)
        else:
            bulid_num = "1"
        zipname = project_name + "_update_" + today + "_" + bulid_num + ".zip"
        return zipname

