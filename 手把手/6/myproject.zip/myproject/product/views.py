import os
import time

from django.db.models import Q
from django.http import HttpResponse

from myproject.settings import BASE_DIR
from product.model import productModel
from UserProduct.models import UserProductModel
from django.views.generic import View
import json
from myproject.utils import DateEncoder
from myproject import rest_searilizers

# 数据库操作
from user.model import userModel


def duplicateVerify(str):
    Record = productModel.objects.filter(Q(name=str) & Q(status=1)).first()  #根据查询结果取第一条
    # Record = userModel.objects.get(username=str) #直接这样取如果结果为空就会报错
    if Record is not None:
        return False
    else:
        return True

#添加
class InsertRecord(View):
    def post(self, request):#post方法
        operateId = request.META['HTTP_X_TOKEN']  # 取得操作员id
        dto = json.loads(request.body)#获取请求的body
        name = dto.get("name", "")#获取name的值,如果没有则赋值为""
        description = dto.get("description", "")
        ftp_path = dto.get("ftp_path", "")
        creator_id = operateId
        status = dto.get("status", "")
        Record_user = userModel(id=creator_id)
        creator_name = Record_user.name
        Record = productModel(name=name, description=description, ftp_path=ftp_path, creator_id=creator_id,
                              status=status, creator_name=creator_name)#新建productModel对象并赋值
        if(duplicateVerify(name)):#判断是否name重复
            Record.save()
            UserProductModel(user_id=operateId, product_id=Record.id).save()
            return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")#返回JSON字符串格式的响应结果{"code": 20000}
        else:
            return HttpResponse(json.dumps({"message": '产品已存在', "code": 10002}), content_type="application/json")

#删除
class DeleteById(View):
    def post(self, request):
        dto = json.loads(request.body)
        Record = productModel.objects.get(id=dto.get('id')) #通过id获取1条QuerySet对象
        Record.delete() #从数据库中删除
        return HttpResponse(json.dumps({"code":20000}),content_type="application/json")

#根据id修改
class UpdateBySelective(View):
    def post(self, request):
        dto = json.loads(request.body)
        id = dto.get('id')
        operateId = request.META['HTTP_X_TOKEN']  # 取得操作员id
        Record = productModel.objects.get(id=id)#objects.get方法,通过获取id获取记录
        if dto.get('name'): #前端是否修改name
            name = dto.get('name')
            if(name != Record.name): #判断是否name重复
                if (duplicateVerify(name)==False):
                    return HttpResponse(json.dumps({"code": 10002, "message": "产品名重复"}), content_type="application/json")
            Record.name = name #name更新为前端修改的值
        if dto.get('description'):
            Record.description = dto.get('description')
        if dto.get('ftp_path'):
            Record.ftp_path = dto.get('ftp_path')
        if dto.get('status'):
            Record.status = dto.get('status')
            if Record.status == 2: #如果状态修改为关闭，记录关闭人和关闭时间
                Record.close_id = operateId
                Record.close_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())#格式化当前时间:2019-04-15 14:23:21
            elif Record.status == 1:
                Record.close_id = None
                Record.close_time = None
                # if dto.get('close_id'):
        #     Record.close_id = dto.get('close_id')
        # if dto.get('close_time'):
        #     Record.close_time = dto.get('close_time')
        Record.save()
        return HttpResponse(json.dumps({"code":20000}),content_type="application/json")

#查询所有
class SelectAll(View):
    def post(self,request):
        listRes = productModel.objects.values()
        listRes = list(listRes)
        return  HttpResponse(json.dumps({"modelList": listRes, "code": 20000},cls=DateEncoder),content_type="application/json")

#根据条件查询
class SelectBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        recordList = productModel.objects.all()
        if dto.get('id'):
            recordList = recordList.filter(id=dto.get('id'))
        if dto.get('productcreate_time'):
            recordList = recordList.filter(productcreate_time=dto.get('productcreate_time'))
        if dto.get('description'):
            recordList = recordList.filter(description=dto.get('description'))
        if dto.get('ftp_path'):
            recordList = recordList.filter(ftp_path=dto.get('ftp_path'))
        if dto.get('creator_id'):
            recordList = recordList.filter(creator_id=dto.get('creator_id'))
        if dto.get('create_time'):
            recordList = recordList.filter(create_time=dto.get('create_time'))
        if dto.get('status'):
            recordList = recordList.filter(status=dto.get('status'))
        if dto.get('close_id'):
            recordList = recordList.filter(close_id=dto.get('close_id'))
        if dto.get('close_time'):
            recordList = recordList.filter(close_time=dto.get('close_time'))
        # listRes = list(recordList)
        listRes = rest_searilizers.ProductSerializer(recordList, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return  HttpResponse(json.dumps({"modelList":data_set,"code":20000},cls=DateEncoder),content_type="application/json")

#分页查询
class SelectByPage(View):
    def post(self,request):
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1)*limit
        sort = dto.get('sort')
        order = dto.get('order')
        targets = productModel.objects.all()
        if dto.get('status'):
            status = dto.get('status')
            targets = productModel.objects.all().filter(status=status)
        if dto.get('search'):
            search = dto.get('search')
            targets = productModel.objects.all().filter(Q(name__icontains=search) | Q(description__icontains=search))
        length = len(targets)
        if not limit:
            targets = productModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        listRes = rest_searilizers.ProductSerializer(targets, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"rows":data_set,"total":length,"code":20000},cls=DateEncoder), content_type='application/json')

#测试接口
class test(View):
    def get(self,request):
        dto = json.loads(request.body)
        projectList = []
        projectList = dto.get('projectList')
        for item in range(projectList):
            id = item['id']
            projectType = item['type']
        command = str(BASE_DIR) + "/shell/ftp_upload.sh"
        ret = os.popen(command)
        msg = ret.readlines()
        for i in range(len(msg)):
            msg[i]=msg[i].strip()
        ret.close()
        return HttpResponse(json.dumps({"msg":msg,"code":20000}), content_type='application/json')





