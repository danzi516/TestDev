# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

#
# 
# @param head ListNode类 
# @return bool布尔型
#
import os

f = open("E:\\test_mml\\333.txt")
f.write("111")
f.close()


