from django.db import models
from user.model import userModel
#定义model，与数据库中保持一致

#id、name...与数据库中的字段一一对应
class productModel(models.Model):
    id = models.AutoField(primary_key=True) #AutoField：自增类型
    name = models.CharField(max_length=255) #CharField:字符串类型
    description = models.CharField(max_length=255)
    ftp_path = models.CharField(max_length=255)
    creator_id = models.IntegerField #IntegerField整形，这里要做关联，所以不规定具体长度
    creator_name = models.CharField(max_length=255)
    create_time = models.DateTimeField(auto_now_add=True) #DateTimeField 时间类型,auto_now_add：新增时取系统时间
    status =models.IntegerField(max_length=11)
    close_id = models.IntegerField
    close_time = models.DateTimeField(auto_now=False)
    creator = models.ForeignKey(userModel, related_name='Product_CreateUser', on_delete=models.CASCADE) #外键关联userModel
    close = models.ForeignKey(userModel, related_name='Product_CloseUser', on_delete=models.CASCADE) #外键关联userModel
    class Meta:
        db_table = "product"  #db_table:表名称

