import json
from django.views.generic import View
from django.http import HttpResponse
from myproject.utils import ModelsUtil
from role.models import RoleModel

#数据库操作
#添加数据
class InsertRecord(View):
    def post(self,request):
        dto = json.loads(request.body)
        name = dto.get("name", "")
        Record = RoleModel(name=name)
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

#删除数据
class DeleteById(View):
    def post(self,request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = RoleModel(id=id)
        Record.delete()
        return  HttpResponse(json.dumps({"code":20000}),content_type="application/json")

#修改数据
class UpdateBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = RoleModel.objects.get(id=id)
        if dto.get('name'):
            Record.name = dto.get('name')
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

#查询所有
class SelectAll(View):
    def post(self,request):
        listRes = RoleModel.objects.values()
        listRes = list(listRes)
        return  HttpResponse(json.dumps({"modelList": listRes, "code": 20000}),content_type="application/json")

#根据条件查询
class SelectBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        recordList = RoleModel.objects.values()
        if dto.get('id'):
            recordList = recordList.filter(id=dto.get('id'))
        if dto.get('name'):
            recordList = recordList.filter(name=dto.get('name'))
        listRes = list(recordList)
        return HttpResponse(json.dumps({"modelList": listRes, "code": 20000}),content_type="application/json")

#分页查询
class SelectByPage(View):
    def post(self,request):
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1) * limit
        sort = dto.get('sort')
        order = dto.get('order')
        length = len(RoleModel.objects.all())
        targets = RoleModel.objects.all()
        if not limit:
            targets = RoleModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        for row in targets:
            data_set.append(ModelsUtil(RoleModel).toDict(row))
        return HttpResponse(json.dumps({"rows":data_set,"total":length,"code":20000}), content_type='application/json')

