from django.apps import AppConfig


class RoleConfig(AppConfig):
    name = 'role'
