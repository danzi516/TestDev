from django.db import models
from django.db import models
class RoleModel(models.Model):
    id = models.IntegerField(primary_key=True, db_column='id')
    name = models.CharField(max_length=255)
    class Meta:
        db_table = "role"


# Create your models here.
