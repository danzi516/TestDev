from django.apps import AppConfig


class ProjectenvironmentConfig(AppConfig):
    name = 'ProjectEnvironment'
