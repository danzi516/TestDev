from django.db import models
from project.models import projectModel
from environment.models import EnvironmentModel
# Create your models here.

class ProjectEnvironmentModel(models.Model):
    id = models.IntegerField(primary_key=True, db_column='id')
    project_id = models.IntegerField
    environment_id = models.IntegerField
    dir_publish = models.CharField(max_length=255)
    log_type = models.IntegerField(max_length=11)
    log_name = models.CharField(max_length=255)
    log_path = models.CharField(max_length=255)
    podname = models.CharField(max_length=255)
    # publish_conf = models.CharField(max_length=255)
    file_conf = models.CharField(max_length=255)
    pod_log_path = models.CharField(max_length=255)
    project = models.ForeignKey(projectModel, related_name='ProjectEnvironment_project', on_delete=models.CASCADE)  # 关联外键
    environment = models.ForeignKey(EnvironmentModel, related_name='ProjectEnvironment_environment', on_delete=models.CASCADE)  # 关联外键
    class Meta:
        db_table = "project_environment"