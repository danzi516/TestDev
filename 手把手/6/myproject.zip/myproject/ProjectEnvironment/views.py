import os

# from myproject.BaseDao import BaseDAO
from django.views.generic import View
from django.http import HttpResponse
from ProjectEnvironment.models import ProjectEnvironmentModel
import json
from myproject.utils import DateEncoder
from myproject import rest_searilizers
from django.db.models import Q
import subprocess

# 数据库操作
from environment.models import EnvironmentModel
from project.models import projectModel


def duplicateVerify(str1, str2):
    Record = ProjectEnvironmentModel.objects.filter(Q(project_id=str1) & Q(environment_id=str2)).first()
    if Record is not None:
        return False
    else:
        return True

# 添加
class InsertRecord(View):
    def post(self, request):
        dto = json.loads(request.body)
        project_id = dto.get("project_id", "")
        environment_id = dto.get("environment_id", "")
        dir_publish = dto.get("dir_publish", "")
        log_type = None
        log_name = None
        if(dto.get("log_type")):
            log_type = dto.get("log_type")
            log_name = dto.get("log_name", "")
        # if(log_type == 2):
        #     log_name = 'catalina.out'
        log_path = dto.get("log_path", "")
        podname = dto.get("podname", "")
        # publish_conf = dto.get("publish_conf","")
        file_conf = dto.get("file_conf","")
        pod_log_path = ''
        if environment_id == 1 and podname:
            cmd = "kubectl get pods `kubectl get pods -n kube-system |grep ^" + podname + " |awk '{print $1}'` -n kube-system -o yaml --export "
            cmd1 = cmd + " |grep mountPath |grep log" #目前可以通过这种方式获取容器里的日志目录,后期变动要修改代码
            cmd2 = cmd + " |grep path |grep -v log |grep -v conf"#目前可以通过这种方式获取发布目录,后期变动要修改代码
            out1 = subprocess.Popen(cmd1, shell=True, stdout=subprocess.PIPE)
            out2 = subprocess.Popen(cmd2, shell=True, stdout=subprocess.PIPE)
            pod_log_path = str(out1.stdout.read().splitlines()[0]).split("mountPath:")[1].strip().split("'")[0]
            dir_publish = str(out2.stdout.read().splitlines()[0]).split("path:")[1].strip().split("'")[0]
        Record = ProjectEnvironmentModel(project_id=project_id, environment_id=environment_id, dir_publish=dir_publish, log_type =log_type,
                                         log_path=log_path, podname=podname,file_conf=file_conf,log_name=log_name,pod_log_path=pod_log_path)
        if(duplicateVerify(project_id,environment_id)):
            Record.save()
            return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
        else:
            return HttpResponse(json.dumps({"message": '记录已存在', "code": 10002}), content_type="application/json")
        # BaseDAO.save(Record)
        # return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")


# 删除
class DeleteById(View):
    def post(self, request):
        dto = json.loads(request.body)
        jsonReq = dto
        Record = ProjectEnvironmentModel.objects.get(id=jsonReq.get('id'))
        Record.delete()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")


# 根据id修改
class UpdateBySelective(View):
    def post(self, request):
        dto = json.loads(request.body)
        id = dto.get('id')
        # project_id = ''
        # environment_id = ''
        Record = ProjectEnvironmentModel.objects.get(id=id)
        # project_id = Record.project_id
        # environment_id = Record.environment_id
        if dto.get('project_id'):
            Record.project_id = dto.get('project_id')
            # if(Record.project_id != project_id):
            #     if (duplicateVerify(project_id,environment_id)==False):
            #         return HttpResponse(json.dumps({"code": 10002, "message": "记录重复"}), content_type="application/json")
        if dto.get('environment_id'):
            Record.environment_id = dto.get('environment_id')
            # if(Record.environment_id != environment_id):
            #     if (duplicateVerify(project_id,environment_id)==False):
            #         return HttpResponse(json.dumps({"code": 10002, "message": "记录重复"}), content_type="application/json")
        if dto.get('dir_publish'):
            Record.dir_publish = dto.get('dir_publish')
        if dto.get('log_type')==1:
            Record.log_type = dto.get('log_type')
            Record.log_name = dto.get('log_name')
        if dto.get('log_type')==2:
            Record.log_type = dto.get('log_type')
            Record.log_name = ''
        if dto.get('log_path'):
            Record.log_path = dto.get('log_path')
        if dto.get('podname'):
            Record.podname = dto.get('podname')
        # if dto.get('publish_conf'):
        #     Record.publish_conf = dto.get('publish_conf')
        if dto.get('file_conf') is not None:
            Record.file_conf = dto.get('file_conf')
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")


# 查询所有
class SelectAll(View):
    def post(self, request):
        listRes = ProjectEnvironmentModel.objects.all()
        listRes = rest_searilizers.ProjectEnvironmentSerializer(listRes, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"modelList": data_set, "code": 20000}, cls=DateEncoder),
                            content_type="application/json")


# 根据条件查询
class SelectBySelective(View):
    def post(self, request):
        recordList = ProjectEnvironmentModel.objects.all()
        dto = json.loads(request.body)
        if dto.get('id'):
            recordList = recordList.filter(id=dto.get('id'))
        if dto.get('project_id'):
            recordList = recordList.filter(project_id=dto.get('project_id'))
        if dto.get('environment_id'):
            recordList = recordList.filter(environment_id=dto.get('environment_id'))
        # if dto.get('dir_publish'):
        #     recordList = recordList.filter(dir_publish=dto.get('dir_publish'))
        if dto.get('log_path'):
            recordList = recordList.filter(log_path=dto.get('log_path'))
        if dto.get('podname'):
            recordList = recordList.filter(podname=dto.get('podname'))
        listRes = rest_searilizers.ProjectEnvironmentSerializer(recordList, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"modelList": data_set, "code": 20000}, cls=DateEncoder),
                            content_type="application/json")


# 分页查询
class SelectByPage(View):
    def post(self, request):
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1) * limit
        sort = dto.get('sort')
        order = dto.get('order')
        length = len(ProjectEnvironmentModel.objects.all())
        targets = ProjectEnvironmentModel.objects.all()
        if not limit:
            targets = ProjectEnvironmentModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        listRes = rest_searilizers.ProjectEnvironmentSerializer(targets, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"rows": data_set, "total": length, "code": 20000},cls=DateEncoder), content_type='application/json')


# shell命令操作
# 重启容器
# class RestartTestByProjectid(View):
#     def post(self, request):
#         dto = json.loads(request.body)
#         project_id = dto.get('project_id')
#         environment_id = dto.get('environment_id')
#         Record = ProjectEnvironmentModel.objects.get(Q(project_id=project_id) & Q(environment_id=environment_id))
#         podname = Record.podname
#         cmd = 'kubectl get pods -n kube-system |grep ^%s | awk \'{print $1}\' | xargs kubectl delete pods -n kube-system'
#         if podname is None:
#             return HttpResponse(json.dumps({"code": 10002}), content_type="application/json")
#         os.system(cmd % (podname))
#         return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")


class UploadDjangoConfig(View):# 类继承View
    def post(self, request):#post请求
        dto = request.POST
        workspace = dto.get('workspace','')
        hostname = dto.get('hostname','')
        if workspace =='' or hostname=='':#文件要存放的位置，缺一个参数就直接返回错误
            return HttpResponse(json.dumps({"message": '参数不正确',"code": 10002}), content_type="application/json")
        if request.FILES:
            myFile = request.FILES.get("file", None)  #获取文件对象
            if myFile:
                dir = os.path.join(workspace, hostname)
                if not os.path.exists(dir):
                    os.makedirs(dir)
                destination = open(os.path.join(dir, myFile.name),'wb+')
                for chunk in myFile.chunks():
                    destination.write(chunk)
                destination.close()
        else:
            return HttpResponse(json.dumps({"message": '上传文件参数错误',"code": 10002}), content_type="application/json")
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

class PhpCopyConfig(View):
    def post(self, request):
        dto = json.loads(request.body)
        project_id = dto.get('project_id')
        environment_id = dto.get('environment_id')
        Record1 = ProjectEnvironmentModel.objects.get(Q(project_id=project_id) & Q(environment_id=environment_id))
        Record2 = projectModel.objects.get(id=project_id)
        Record3 = EnvironmentModel.objects.get(id=environment_id)
        dir_publish = Record1.dir_publish
        file_conf = Record1.file_conf
        projectname = Record2.name
        publish_conf = Record2.publish_conf
        workspace = Record2.workspace
        projecttype = Record2.type
        hostname = Record3.hostname
        dir1 = os.path.join(workspace, hostname, file_conf)
        dir2 = os.path.join(dir_publish, projectname, publish_conf)
        dir3 = os.path.join(dir_publish, publish_conf)
        if projecttype == 3:
            if file_conf is None or file_conf == '':
                return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
            elif publish_conf is None or publish_conf == '':
                return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
            else:
                if os.path.exists(dir1) is False:
                    return HttpResponse(json.dumps({"message": '配置文件不存在,请重新上传配置文件', "code": 10002}), content_type="application/json")
                elif os.path.exists(dir2) is False:
                    return HttpResponse(json.dumps({"message": '应用配置路径错误,请检查配置', "code": 10002}), content_type="application/json")
                else:
                    command = "cp -f %s %s"
                    os.system(command % (dir1, dir2))
                    return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
        elif projecttype == 4:
            if file_conf is None or file_conf == '':
                return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
            elif publish_conf is None or publish_conf == '':
                return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
            else:
                if os.path.exists(dir1) is False:
                    return HttpResponse(json.dumps({"message": '配置文件不存在,请重新上传配置文件', "code": 10002}), content_type="application/json")
                elif os.path.exists(dir3) is False:
                    return HttpResponse(json.dumps({"message": '应用配置路径错误,请检查配置', "code": 10002}), content_type="application/json")
                else:
                    command = "cp -f %s %s"
                    os.system(command % (dir1, dir3))
                    return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
# Create your views here.
