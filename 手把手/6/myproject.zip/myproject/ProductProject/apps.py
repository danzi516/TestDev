from django.apps import AppConfig


class ProductprojectConfig(AppConfig):
    name = 'ProductProject'
