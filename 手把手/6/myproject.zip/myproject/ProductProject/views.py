from django.db.models import Q
from django.views.generic import View
from django.http import HttpResponse
from ProductProject.models import ProductProjectModel
from myproject import rest_searilizers
import json
from myproject.utils import DateEncoder

# 数据库操作
def duplicateVerify(str1, str2):
    Record = ProductProjectModel.objects.filter(Q(product_id=str1) & Q(project_id=str2)).first()
    if Record is not None:
        return False
    else:
        return True

# 添加
class InsertRecord(View):
    def post(self, request):
        dto = json.loads(request.body)
        project_id = dto.get("project_id", "")
        product_id = dto.get("product_id", "")
        Record = ProductProjectModel(project_id=project_id, product_id=product_id)
        if (duplicateVerify(product_id, project_id)):
            Record.save()
            return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")
        else:
            return HttpResponse(json.dumps({"message": '记录已存在', "code": 10002}), content_type="application/json")

# 添加关联组件
class InsertAllRecord(View):
    def post(self, request):
        dto = json.loads(request.body)
        projectIdList = dto.get("project_id", "")
        product_id = dto.get("product_id", "")
        # 根据productid删除所有
        Records = ProductProjectModel.objects.filter(product_id=product_id)
        if Records:
            Records.delete()
        for item in projectIdList:
            project_id = item
            Record = ProductProjectModel(project_id=project_id, product_id=product_id)
            Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

# 删除
class DeleteById(View):
    def post(self, request):
        dto = json.loads(request.body)
        jsonReq = dto
        Record = ProductProjectModel.objects.get(id=jsonReq.get('id'))
        Record.delete()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

# 根据id修改
class UpdateBySelective(View):
    def post(self, request):
        dto = json.loads(request.body)
        id = dto.get('id')
        # product_id = ''
        # project_id = ''
        Record = ProductProjectModel.objects.get(id=id)
        product_id = Record.product_id
        project_id = Record.project_id
        if dto.get('project_id'):
            Record.project_id = dto.get('project_id')
            if (Record.project_id != project_id):
                if (duplicateVerify(product_id, Record.project_id) == False):
                    return HttpResponse(json.dumps({"code": 10002, "message": "记录重复"}), content_type="application/json")
        if dto.get('product_id'):
            Record.product_id = dto.get('product_id')
            if (Record.product_id != product_id):
                if (duplicateVerify(Record.product_id, project_id) == False):
                    return HttpResponse(json.dumps({"code": 10002, "message": "记录重复"}), content_type="application/json")
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

# 查询所有
class SelectAll(View):
    def post(self, request):
        listRes = ProductProjectModel.objects.all()
        listRes = rest_searilizers.ProductProjectSerializer(listRes, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"modelList": data_set, "code": 20000}, cls=DateEncoder),
                            content_type="application/json")

# 根据条件查询
class SelectBySelective(View):
    def post(self, request):
        recordList = ProductProjectModel.objects.all()
        dto = json.loads(request.body)
        if dto.get('id'):
            recordList = recordList.filter(id=dto.get('id'))
        if dto.get('project_id'):
            recordList = recordList.filter(project_id=dto.get('project_id'))
        if dto.get('product_id'):
            recordList = recordList.filter(product_id=dto.get('product_id'))
        if dto.get('projectName'):
            search = dto.get('projectName')
            recordList = recordList.filter(project__name__icontains=search) #根据外键查出的project的name进行筛选
        listRes = rest_searilizers.ProductProjectSerializer(recordList, many=True) #序列化查询结果
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"modelList": data_set, "code": 20000}, cls=DateEncoder),
                            content_type="application/json")

# 分页查询
class SelectByPage(View):
    def post(self, request):
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1) * limit
        sort = dto.get('sort')
        order = dto.get('order')
        length = len(ProductProjectModel.objects.all())
        targets = ProductProjectModel.objects.all()
        if not limit:
            targets = ProductProjectModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        listRes = rest_searilizers.ProductProjectSerializer(targets, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse({"rows": data_set, "total": length, "code": 20000}, content_type='application/json')
# Create your views here.
