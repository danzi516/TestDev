"""Django URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from ProductProject import views
urlpatterns = [

    path('InsertRecord', views.InsertRecord.as_view(), name='save'), #name 可以用于在 templates, models, views ……中得到对应的网址，相当于“给网址取了个名字”，只要这个名字不变，网址变了也能通过名字获取到
    path('DeleteById', views.DeleteById.as_view()),
    path('UpdateBySelective', views.UpdateBySelective.as_view()),
    path('SelectAll', views.SelectAll.as_view()),
    path('SelectBySelective', views.SelectBySelective.as_view()),
    path('SelectByPage', views.SelectByPage.as_view()),
    path('InsertAllRecord', views.InsertAllRecord.as_view()),
]
