from django.db import models
from product.model import productModel
from project.models import projectModel
class ProductProjectModel(models.Model):
    id = models.IntegerField(primary_key=True, db_column='id')
    product_id = models.IntegerField
    project_id = models.IntegerField
    project = models.ForeignKey(projectModel, related_name='ProductProject_project', on_delete=models.CASCADE)  # 关联外键
    product = models.ForeignKey(productModel, related_name='ProductProject_product', on_delete=models.CASCADE)  # 关联外键
    class Meta:
        db_table = "product_project"


# Create your models here.
