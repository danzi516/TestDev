from django.test import TestCase
import time
import paramiko

# #创建SSH对象
# ssh = paramiko.SSHClient()
#
# #把要连接的机器添加到known_hosts文件中
# ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
#
# #连接服务器
# ssh.connect(hostname='172.23.200.27', port=22, username='root', password='Vm201806@')
# # sftp_client = ssh.open_sftp()
# # remote_file = sftp_client.open("/usr/local/tomcat8.5/logs/debug.log", 'r+')
# #
# # print(remote_file)
# cmd = 'cd /usr/local/tomcat8.5/logs'
# #cmd = 'ls -l;ifconfig'       #多个命令用;隔开
# stdin, stdout, stderr = ssh.exec_command(cmd)


client = paramiko.SSHClient()
try:
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname='172.23.200.27', port=22, username='root', password='Vm201806@', timeout=5)
    sftp_client = client.open_sftp()
    # remote_file = sftp_client.open("/usr/local/tomcat8.5/logs/debug.log", 'r+')
    '''
    your code to operate the remote file
    '''
    # b_ncfile = remote_file.read()
    # print(b_ncfile)
    # remote_file.close()
    remote_file = sftp_client.open("/usr/local/tomcat8.5/logs/debug.log", 'r+')
    remote_file.prefetch()
    try:
        with remote_file as f:
            f.seek(0, 2)

            while True:
                line = f.readline().strip()
                if line:
                    print(line)
                else:
                    time.sleep(0.5)
    except Exception as e:
        print(e)
except:
    print('failed to open the remote file!')
finally:
    client.close()
