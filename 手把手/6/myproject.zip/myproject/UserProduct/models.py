from django.db import models
from product.model import productModel
from user.model import userModel
class UserProductModel(models.Model):
    id = models.IntegerField(primary_key=True, db_column='id')
    user_id = models.IntegerField
    product_id = models.IntegerField
    user_type = models.IntegerField(max_length=11)
    user = models.ForeignKey(userModel, related_name='UserProduct_user', on_delete=models.CASCADE)  # 关联外键
    product = models.ForeignKey(productModel, related_name='UserProduct_product', on_delete=models.CASCADE)  # 关联外键
    class Meta:
        db_table = "user_product"
# Create your models here.
