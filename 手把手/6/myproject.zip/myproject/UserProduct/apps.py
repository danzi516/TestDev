from django.apps import AppConfig


class UserproductConfig(AppConfig):
    name = 'UserProduct'
