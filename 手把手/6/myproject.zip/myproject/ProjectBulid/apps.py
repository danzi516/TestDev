from django.apps import AppConfig


class ProjectbulidConfig(AppConfig):
    name = 'ProjectBulid'
