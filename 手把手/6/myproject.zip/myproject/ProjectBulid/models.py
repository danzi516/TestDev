from django.db import models
from project.models import projectModel

class ProjectBulidModel(models.Model):
    id = models.AutoField(primary_key=True, db_column='id')
    name = models.CharField(max_length=255)
    project_id = models.IntegerField
    type = models.IntegerField(max_length=11)
    status = models.IntegerField(max_length=11)
    info = models.TextField(max_length=5000)
    SVNversion = models.CharField(max_length=11)
    workspace = models.CharField(max_length=255)
    create_uid = models.IntegerField(max_length=11)
    create_time = models.DateTimeField(auto_now_add=True)
    project = models.ForeignKey(projectModel, related_name='ProjectBulid_project',on_delete=models.CASCADE)  # 关联外键
    class Meta:
        db_table = "project_bulid"

