from django.db import models
from credentials.models import CredentialsModel

# Create your models here.
class EnvironmentModel(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    # type = models.IntegerField(max_length=11)
    hostname = models.CharField(max_length=255)
    credentials_id = models.IntegerField
    credentials = models.ForeignKey(CredentialsModel, related_name='Environment_credentials',on_delete=models.CASCADE)  # 关联外键
    class Meta:
        db_table = "environment"

