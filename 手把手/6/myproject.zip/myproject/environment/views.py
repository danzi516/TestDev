import json
from django.views.generic import View
from django.http import HttpResponse
# from myproject.BaseDao import BaseDAO
from myproject.utils import DateEncoder
from environment.models import EnvironmentModel
from myproject import rest_searilizers


#数据库操作
#添加数据
class InsertRecord(View):
    def post(self,request):
        dto = json.loads(request.body)
        name = dto.get("name","")
        # type = dto.get("type","")
        hostname = dto.get("hostname", "")
        credentials_id = dto.get("credentials_id", "")
        Record = EnvironmentModel(name=name, hostname=hostname,credentials_id=credentials_id)
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

#删除数据
class DeleteById(View):
    def post(self,request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = EnvironmentModel(id=id)
        Record.delete()
        return  HttpResponse(json.dumps({"code":20000}),content_type="application/json")

#修改数据
class UpdateBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = EnvironmentModel.objects.get(id=id)
        if dto.get('name'):
            Record.name = dto.get('name')
        # if dto.get('type'):
        #     Record.type = dto.get('type')
        if dto.get('hostname'):
            Record.hostname = dto.get('hostname')
        if dto.get('credentials_id'):
            Record.credentials_id = dto.get('credentials_id')
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")

#查询所有
class SelectAll(View):
    def post(self,request):
        listRes = EnvironmentModel.objects.all()
        listRes = rest_searilizers.EnvironmentSerializer(listRes, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"modelList": data_set, "code": 20000}, cls=DateEncoder),content_type="application/json")

#根据条件查询
class SelectBySelective(View):
    def post(self,request):
        dto = json.loads(request.body)
        recordList = EnvironmentModel.objects.all()
        if dto.get('id'):
            recordList = recordList.filter(id=dto.get('id'))
        if dto.get('name'):
            recordList = recordList.filter(name=dto.get('name'))
        # if dto.get('type'):
        #     recordList = recordList.filter(type=dto.get('type'))
        if dto.get('hostname'):
            recordList = recordList.filter(hostname=dto.get('hostname'))
        if dto.get('credentials_id'):
            recordList = recordList.filter(credentials_id=dto.get('credentials_id'))
        listRes = rest_searilizers.EnvironmentSerializer(recordList, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return  HttpResponse(json.dumps({"modelList":data_set,"code":20000},cls=DateEncoder),content_type="application/json")

#分页查询
class SelectByPage(View):
    def post(self,request):
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1) * limit
        sort = dto.get('sort')
        order = dto.get('order')
        targets = EnvironmentModel.objects.all()
        if dto.get('search'):
            search = dto.get('search')
            targets = EnvironmentModel.objects.all().filter(name__icontains=search)
        length = len(targets)
        if not limit:
            targets = EnvironmentModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        listRes = rest_searilizers.EnvironmentSerializer(targets, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"rows":data_set,"total":length,"code":20000}), content_type='application/json')

