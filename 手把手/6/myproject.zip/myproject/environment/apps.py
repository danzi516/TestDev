from django.apps import AppConfig


class EnvironmentConfig(AppConfig):
    name = 'environment'
