import json
import sys

import paramiko
from django.http import HttpResponse
from django.views.generic import View

from myproject.settings import BASE_DIR
from myproject.utils import DateEncoder, connectDB

#查询试运行环境和生产环境所有的数据库列表
class QueryDB(View):
    def post(self, request):
        dto = json.loads(request.body)
        environment = int(dto.get('environment'))
        en_command1 = "mysql -uwriteuser -P 3313 -h 127.0.0.1 -pjiaparts@rw -e "
        en_command2 = "mysql -ureaduser -P 3311 -h 127.0.0.1 -pjiaparts@ro -e "
        command_ex = 'show databases;'
        if environment == 1 and command_ex is not None and command_ex != '':
            command = "%s \"%s\" |grep -Ev \"Database|information_schema|mysql|sys|performance_schema\" >/tmp/list_db.txt" %(en_command1, command_ex)
        elif environment == 2 and command_ex is not None and command_ex != '':
            command = "%s \"%s\" |grep -Ev \"Database|information_schema|mysql|sys|performance_schema\" >/tmp/list_db.txt" % (en_command2, command_ex)
        else:
            return HttpResponse(json.dumps({"message": '未操作任何内容', "code": 20000},cls=DateEncoder), content_type='application/json')
        channel, client = connectDB()
        channel.sendall(command + '\n')  # 发送命令
        buff = ''
        try:
            while buff.find('# ') == -1:
                resp = channel.recv(9999)
                buff += resp.decode()
        except Exception as e:
            print("错误:" + str(e))
        channel.sendall('cat /tmp/list_db.txt' + '\n')  # 发送命令
        buff = ''
        try:
            while buff.find('# ') == -1:
                resp = channel.recv(9999)
                buff += resp.decode()
        except Exception as e:
            print("错误:" + str(e))
        file_handle = open("%s/log/list_db.txt" % (BASE_DIR), 'w')
        buff = buff.replace("\n",'')
        # buff = buff.replace("\r",'')
        file_handle.write(buff)
        file_handle.close()
        file_handle = open('%s/log/list_db.txt' % (BASE_DIR), mode='r')
        content = file_handle.readlines()
        line = content[1:-1]
        for i in range(len(line)):
            list = []
            line[i] = line[i].rstrip("\n")
            list.append(line)
        file_handle.close()
        channel.close()
        client.close()
        return HttpResponse(json.dumps({"list": list, "code": 20000},cls=DateEncoder), content_type='application/json')

#查询试运行环境和生产环境的验证码
class QueryVcode(View):
    def post(self,request):
        dto = json.loads(request.body)
        telephone = dto.get('telephone')
        limit = 5
        command = ''
        if dto.get('limit'):
            limit = int(dto.get('limit'))
        environment = int(dto.get('environment'))
        en_command1 = "mysql -uwriteuser -P 3313 -h 127.0.0.1 -pjiaparts@rw -e "
        en_command2 = "mysql -ureaduser -P 3311 -h 127.0.0.1 -pjiaparts@ro -e "
        # command1 = "select v_code,cell_phone from bnsdb.reg_verification where status = 0 and CELL_PHONE = '%s' order by id desc limit %s;" % (telephone, limit)
        command1 = "select b.CELL_PHONE,b.V_CODE,b.EXPIRE_TIME from (SELECT MAX(t.ID) id FROM bnsdb.reg_verification t where STATUS=0 GROUP BY CELL_PHONE) a INNER JOIN bnsdb.reg_verification b on a.id=b.id where b.CELL_PHONE='%s';" % (telephone)
        # command2 = "select v_code,cell_phone from bnsdb.reg_verification where status = '0' order by id desc limit %s;" % (limit)
        command2 = "select b.CELL_PHONE,b.V_CODE,b.EXPIRE_TIME from (SELECT MAX(t.ID) id FROM bnsdb.reg_verification t where STATUS=0 GROUP BY CELL_PHONE) a INNER JOIN bnsdb.reg_verification b on a.id=b.id ORDER BY b.id desc LIMIT %s;" % (limit)
        if environment == 1 and telephone != '':
            command = "%s '%s' |awk '{print $1\"|\"$2\"|\"$3\"|\"$4}' >/tmp/list_vcode.txt" % (en_command1, command1)
        elif environment == 1 and telephone == '':
            command = "%s '%s' |awk '{print $1\"|\"$2\"|\"$3\"|\"$4}' >/tmp/list_vcode.txt" % (en_command1, command2)
        elif environment == 2 and telephone != '':
            command = "%s '%s' |awk '{print $1\"|\"$2\"|\"$3\"|\"$4}' >/tmp/list_vcode.txt" % (en_command2, command1)
        elif environment == 2 and telephone == '':
            command = "%s '%s' |awk '{print $1\"|\"$2\"|\"$3\"|\"$4}' >/tmp/list_vcode.txt" % (en_command2, command2)
        channel, client = connectDB()
        channel.sendall(command + '\n')  # 发送命令
        buff = ''
        try:
            while buff.find('# ') == -1:
                resp = channel.recv(9999)
                buff += resp.decode()
        except Exception as e:
            print("错误:" + str(e))
        channel.sendall('cat /tmp/list_vcode.txt' + '\n')  # 发送命令
        buff = ''
        try:
            while buff.find('# ') == -1:
                resp = channel.recv(9999)
                buff += resp.decode()
        except Exception as e:
            print("错误:" + str(e))
        file_handle = open("%s/log/list_vcode.txt" % (BASE_DIR), 'w')
        buff = buff.replace("\n",'')
        # buff = buff.replace("\r",'')
        file_handle.write(buff)
        file_handle.close()
        file_handle = open('%s/log/list_vcode.txt' % (BASE_DIR), mode='r')
        content = file_handle.readlines()
        list = []
        for i in range(2,len(content)-1):
            item = {}
            line = content[i].rstrip("\n")
            line = line.split('|')
            item['phone'] =line[0]
            item['vcode'] = line[1]
            item['expire_time'] = line[2]+' '+line[3]
            list.append(item)
        file_handle.close()
        channel.close()
        client.close()
        return HttpResponse(json.dumps({"list": list, "code": 20000},cls=DateEncoder), content_type='application/json')

#执行试运行环境和生产环境的sql，试运行只能执行增删改查，生产智能查询
class QueryCode(View):
    def post(self,request):
        dto = json.loads(request.body)
        DBname = dto.get('dbname')
        command_ex = dto.get('command')
        command_ex = command_ex.lower()
        command_ex = command_ex.replace("`","")
        environment = int(dto.get('environment'))
        en_command1 = "mysql -uwriteuser -P 3313 -h 127.0.0.1 -pjiaparts@rw -e "
        en_command2 = "mysql -ureaduser -P 3311 -h 127.0.0.1 -pjiaparts@ro -e "
        if environment == 1 and command_ex is not None and command_ex != '':
            command = "%s \"use %s;%s\"  >/tmp/list_command.txt" % (en_command1, DBname, command_ex)
        elif environment == 2 and command_ex is not None and command_ex != '':
            command = "%s \"use %s;%s\"  >/tmp/list_command.txt" % (en_command2, DBname, command_ex)
        else:
            return HttpResponse(json.dumps({"message": '未操作任何内容', "code": 20000},cls=DateEncoder), content_type='application/json')
        channel, client = connectDB()
        if command_ex[0:6] == 'update' or command_ex[0:6] == 'insert' or command_ex[0:6] == 'delete':
            if environment == 2:
                return HttpResponse(json.dumps({"message": '生产环境只允许查询', "code": 10002}),content_type='application/json')
            channel.sendall(command + '\n')  # 发送命令
            buff = ''
            try:
                while buff.find('# ') == -1:
                    resp = channel.recv(9999)
                    buff += resp.decode()
                channel.close()
                client.close()
                return HttpResponse(json.dumps({"message": '执行成功', "code": 20000}), content_type='application/json')
            except Exception as e:
                # print("错误:" + str(e))
                error = "错误:" + str(e)
                channel.close()
                client.close()
                return HttpResponse(json.dumps({"message": '执行失败,' + error, "code": 20000}), content_type='application/json')
        elif command_ex[0:6] == 'select':
            channel.sendall(command + '\n')  # 发送命令
            buff = ''
            try:
                while buff.find('# ') == -1:
                    resp = channel.recv(9999)
                    buff += resp.decode()
            except Exception as e:
                # print("错误:" + str(e))
                error = "错误:" + str(e)
                return HttpResponse(json.dumps({"message": '执行失败1,' + error, "code": 20000}), content_type='application/json')
            channel.sendall('cat /tmp/list_command.txt' + '\n')  # 发送命令
            buff = ''
            try:
                while buff.find('# ') == -1:
                    resp = channel.recv(9999)
                    buff += resp.decode("utf8","ignore")
            except Exception as e:
                # print("错误:" + str(e))
                error = "错误:" + str(e)
                return HttpResponse(json.dumps({"message": '执行失败2,' + error, "code": 20000}), content_type='application/json')
            file_handle = open("%s/log/list_command.txt" % (BASE_DIR), 'w')
            buff = buff.replace("\n",'')
            # buff = buff.replace("\r",'')
            file_handle.write(buff)
            file_handle.close()
            file_handle = open('%s/log/list_command.txt' % (BASE_DIR), mode='r')
            content = file_handle.readlines()
            field = content[1]
            field = field.rstrip("\n")
            field = field.split("\t")
            content = content[2:-1]
            list = []
            for i in range(len(content)):
                item = {}
                for j in range(len(field)):
                    line = content[i].rstrip("\n")
                    line = line.split("\t")
                    item[field[j]] = line[j]
                list.append(item)
            file_handle.close()
            channel.close()
            client.close()
            if list == []:
                return HttpResponse(json.dumps({"message": '查询结果为空', "code": 20000}, cls=DateEncoder),content_type='application/json')
            return HttpResponse(json.dumps({"list": list, "code": 20000},cls=DateEncoder), content_type='application/json')
        else:
            channel.close()
            client.close()
            return HttpResponse(json.dumps({"message": '只允许执行增删改查', "code": 10002}), content_type='application/json')
