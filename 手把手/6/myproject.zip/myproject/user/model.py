from django.db import models
#定义model，与数据库中保持一致
class userModel(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    status =models.IntegerField(max_length=11)
    create_time = models.DateTimeField(auto_now_add=True)
    class Meta:
        db_table = "user"

# Create your models here.
