import sys

import paramiko
from django.http import HttpResponse

from myproject.settings import BASE_DIR
from UserRole.models import UserRoleModel
from myproject import rest_searilizers
from user.model import userModel
# from myproject.BaseDao import BaseDAO
from django.views.generic import View
import json
import datetime
from myproject.utils import DateEncoder, ModelsUtil, Encrypted_text, Decrypted_text, connectDB
from django.db.models import Q

# 数据库操作
def duplicateVerify(str):
    Record = userModel.objects.filter(username=str).first()
    # Record = userModel.objects.get(username=str)
    if Record is not None:
        return False
    else:
        return True
#添加
class InsertRecord(View):
    def post(self, request):
        dto = json.loads(request.body)
        username = dto.get("username","")
        password = dto.get("password", "")
        password = Encrypted_text(password)
        name = dto.get("name", "")
        status = dto.get("status", "")
        roleValue = dto.get("roleValue", "")
        Record = userModel(username=username,password=password,name=name,status=status)
        if(duplicateVerify(username)):
            Record.save()
            userId = Record.id
            UserRoleModel(user_id=userId,role_id=roleValue).save()
            return HttpResponse(json.dumps({"code":20000}),content_type="application/json")
        else:
            return HttpResponse(json.dumps({"code":10002,"message":"用户名重复"}),content_type="application/json")
#删除
class DeleteById(View):
    def post(self, request):
        dto = json.loads(request.body)
        jsonReq = dto
        Record = userModel.objects.get(id=jsonReq.get('id'))
        Record.delete()
        return HttpResponse(json.dumps({"code":20000}),content_type="application/json")

#根据id修改
class UpdateBySelective(View):
    def post(self, request):
        dto = json.loads(request.body)
        id = dto.get('id')
        Record = userModel.objects.get(id=id)
        if dto.get('username'):
            username = dto.get('username')
            if(username != Record.username):
                if (duplicateVerify(username)==False):
                    return HttpResponse(json.dumps({"code": 10002, "message": "用户名重复"}), content_type="application/json")
            Record.username = dto.get('username')
        if dto.get('password'):
            Record.password = Encrypted_text(dto.get('password'))
        if dto.get('name'):
            Record.name = dto.get('name')
        if dto.get('status')is not None:
            Record.status = dto.get('status')
        Record.save()
        return HttpResponse(json.dumps({"code": 20000}), content_type="application/json")


#查询所有
class SelectAll(View):
    def post(self,request):
        listRes = userModel.objects.values()
        listRes = list(listRes)
        data_set = json.dumps({"modelList": listRes, "code": 20000}, cls=DateEncoder)
        return  HttpResponse(data_set,content_type="application/json")

#根据条件查询
class SelectBySelective(View):
    def post(self,request):
        recordList = userModel.objects.all()
        dto = json.loads(request.body)
        if dto.get('id'):
            recordList = recordList.filter(id=dto.get('id'))
        if dto.get('username'):
            recordList = recordList.filter(username=dto.get('username'))
        if dto.get('password'):
            recordList = recordList.filter(password=dto.get('password'))
        if dto.get('name'):
            recordList = recordList.filter(name=dto.get('name'))
        if dto.get('status'):
            recordList = recordList.filter(status=dto.get('status'))
        if dto.get('create_time'):
            recordList = recordList.filter(create_time=dto.get('create_time'))
        # listRes = list(recordList)
        listRes = rest_searilizers.UserSerializer(recordList, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return  HttpResponse(json.dumps({"modelList":data_set,"code":20000},cls=DateEncoder),content_type="application/json")

#分页查询
class SelectByPage(View):
    def post(self,request):
        dto = json.loads(request.body)
        data_set = []
        limit = int(dto.get('rows'))
        offset = (int(dto.get('page')) - 1)*limit
        sort = dto.get('sort')
        order = dto.get('order')
        targets = userModel.objects.all()
        if dto.get('search'):
            search = dto.get('search')
            targets= userModel.objects.all().filter(Q(username__icontains=search)|Q(name__icontains=search))
        length = len(targets)
        if not limit:
            targets = userModel.objects.all()
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)
        else:
            offset = int(offset)
            limit = int(limit)
            if sort:
                sort = sort if order == 'asc' else '-' + sort
                targets = targets.order_by(sort)[offset:offset + limit]
            else:
                targets = targets[offset:offset + limit]
        listRes = rest_searilizers.UserSerializer(targets, many=True)
        data_set = json.dumps(listRes.data, cls=DateEncoder)
        data_set = json.loads(data_set)
        return HttpResponse(json.dumps({"rows":data_set,"total":length, "code": 20000},cls=DateEncoder), content_type='application/json')

#登录接口
class Login(View):
    def post(self,request):
        dto = json.loads(request.body)
        username = dto.get("username")
        password = dto.get("password")
        recordList = userModel.objects.values().filter(Q(username=username)&Q(password=Encrypted_text(password)))
        if len(recordList)>0:
            return HttpResponse(json.dumps({"data": list(recordList), "code": 20000},cls=DateEncoder), content_type='application/json')
        return HttpResponse(json.dumps({"message":"用户名或密码不对","code":10002}), content_type='application/json')
