<template>
  <div class="app-container">
    <div class="filter-container">
      <el-input v-model="listQuery.search" placeholder="产品名称" style="width: 200px;" class="filter-item" />
      <el-button class="filter-item" type="primary" icon="el-icon-search">
        查询
      </el-button>
      <el-button class="filter-item" style="margin-left: 10px;" type="success" icon="el-icon-edit">
        添加
      </el-button>
    </div>
    <el-table
      v-loading="listLoading"
      :data="list"
      border
      highlight-current-row
      style="width: 100%;"
    >
      <el-table-column label="产品名称" min-width="35px" align="center">
        <template slot-scope="{row}">
          <span style="padding-right:20px">{{ row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="描述" min-width="50px" align="center">
        <template slot-scope="{row}">
          <span class="link-type">{{ row.description }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Status" class-name="status-col" width="100" align="center">
        <template slot-scope="{row}">
          <el-tag :type="row.status | statusFilter">
            {{ row.status=="2"?"禁用":"正常" }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="{row}">
          <el-button type="primary" size="mini">
            修改
          </el-button>
          <el-button v-if="row.status==1" size="mini" type="danger">
            禁用
          </el-button>
          <el-button v-if="row.status==2" size="mini" type="success">
            启用
          </el-button>
          <el-button size="mini" type="success">
            关联组件
          </el-button>
          <el-button size="mini" type="warning">
            版本管理
          </el-button>
          <el-button size="mini">
            团队管理
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination v-show="total>0" :total="total" :page.sync="listQuery.page" :limit.sync="listQuery.rows" @pagination="getList" />
  </div>
</template>

<script>
import { selectByPage } from '@/api/productManage'
import Pagination from '@/components/Pagination'

export default {
  name: 'ProductManage',
  components: { Pagination }, // 分页组件
  filters: {
    statusFilter(status) {
      const statusMap = {
        1: 'success',
        2: 'danger'
      }
      return statusMap[status]
    }
  },
  data() {
    return {
      list: null,
      total: 0,
      listLoading: true,
      listQuery: {
        page: 1,
        rows: 10,
        search: undefined
      }
    }
  },
  created() {
    this.getList()
  },
  methods: {
    getList() {
      selectByPage(this.listQuery).then(response => {
        console.log(response)
        this.listLoading = false
        this.list = response.rows
        this.total = response.total
      })
    }
  }
}

</script>
<style lang='less' scoped>
</style>
