import request from '@/utils/request'

export function selectByPage(data) {
  return request({
    url: '/product/SelectByPage',
    method: 'post',
    data
  })
}

export function insertRecord(data) {
  return request({
    url: '/product/InsertRecord',
    method: 'post',
    data
  })
}

export function updateBySelective(data) {
  return request({
    url: '/product/UpdateBySelective',
    method: 'post',
    data
  })
}
